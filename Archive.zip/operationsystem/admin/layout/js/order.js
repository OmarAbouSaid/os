$(document).ready(function(){
    var DOMAIN = "http://192.168.64.2/operationsystem/admin";
    $("#add").click(function(){
        addNewRow()
    })
function addNewRow(){
    $.ajax({
        url : DOMAIN+"/includes/process.php",
        method : "POST",
        data : {getNewOrderItem:1},
        success: function(data){
            alert(data);

        }
    })
}
});