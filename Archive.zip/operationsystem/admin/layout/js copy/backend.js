$(function (){
    'use strict';
    // //hide placeholder on form focus

    // $('[placeholder]').focus(function(){

    //     $(this).attr('data-text',$(this).attr('placeholder'));

    //     $(this).attr('placeholder','');

    // }).blur(function (){

    //     $(this).attr('placeholder',$(this).attr('data-text'));
    // });
    //add asterisk on required fields

    // $('input').each(function(){
    //     if($(this).attr('required') === 'required'){
    //         $(this).after('<span class="asterisk">*</span>');
    //     }
    // });
    //confirmation message on bottom
    $('.confirm').click(function(){
        return confirm('Are you sure you want to delete this User');
    });
});