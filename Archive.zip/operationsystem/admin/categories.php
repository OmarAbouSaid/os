<?php
ob_start();
session_start();
$pageTitle = 'Categories';
if(isset($_SESSION['Username'])){
    include 'init.php';
    $do = isset($_GET['do']) ? $_GET['do']: 'Manage';
    if($do == 'Manage'){
        $sort = 'ASC';
        $sort_array = array('ASC','DESC');
        if(isset($_GET['sort']) && in_array($_GET['sort'], $sort_array)){
            $sort = $_GET['sort'];
        }
    $stmt2 = $con->prepare("SELECT * FROM categories ORDER BY ID $sort");
    $stmt2->execute();
    $cats = $stmt2->fetchAll();
    $count = $stmt2->rowCount();
    if($count > 0 ){
    ?>                        
    <div class="container ">       
     <h3 class="">Manage Categories</h3>
        <div class="ordering float-right">
            <span>Category sort by Date</span>
            <a class="<?php if($sort == 'ASC'){echo 'active';} ?>" href="categories.php?sort=ASC"><i class="fa fa-arrow-up"></i></a>
            <a class="<?php if($sort == 'DESC'){echo 'active';} ?>" href="categories.php?sort=DESC"><i class="fa fa-arrow-down"></i></a>
        </div>
        <!-- accordion -->
            <div class="" id="accordionCat">
            <?php 
            $i = 100;     
            foreach($cats as $cat){      
                /////////
            echo '<div class="accordion-item">';
                echo '<h5 class="accordion-header" id="heading'.$i.'">';
                echo '<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse'.$i.'" aria-expanded="false" aria-controls="collapse'.$i.'">';
                    echo $cat['Name'];
                echo '</button>';
                echo '</h5>';
                echo '<div id="collapse'.$i.'" class="accordion-collapse collapse" aria-labelledby="heading" data-bs-parent="#accordionCat">';
                echo '<div class="accordion-body">';
                echo '<table class="table text-center">';
                echo '<thead>';
                    echo '<tr>';
                    echo '<th scope="col">Name</th>';
                    echo '<th scope="col">Control</th>';
                    echo '</tr>';
                    echo '</thead>';
                    echo '<tbody>';
                    echo '<tr>';
                    echo '<td>'.$cat['Name'].'</td>';
                    echo '<td><a href="categories.php?do=Edit&catid='.$cat['ID'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> <a href="categories.php?do=Delete&catid='.$cat['ID'].'" class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a></td><a href="categories.php?do=AddSub&subid='.$cat['ID'].'" class="btn btn-outline-primary btn-sm"><i class="fa fa-plus"></i> Add Sub Category</a>';
                    echo '</tr>';
                    echo '</tbody>';
                    echo '</table>';   
                    //echo $cat['ID'].'<br>';
                    //echo ' sub category<br>';
                    ///////////sub cat
                    $stmt3 = $con->prepare("SELECT * FROM subcategory WHERE SubID = ?");
                    $stmt3->execute(array($cat['ID']));
                    $subcats = $stmt3->fetchAll();
                    $count = $stmt3->rowCount();
                    $j = 987;     
                    foreach($subcats as $subcat){
                        ?>
                        <div class="container" >
                            <div class="accordion" >
                                <div class="accordion-item">
                                    <h6 class="accordion-header" id="panelsStayOpen-heading<?php echo $j; ?>">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse<?php echo $j; ?>" aria-expanded="false" aria-controls="panelsStayOpen-collapse<?php echo $j; ?>">
                                        <?php echo $subcat['SubName']; ?>
                                    </button>
                                    </h6>
                                        <div id="panelsStayOpen-collapse<?php echo $j; ?>" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-heading<?php echo $j; ?>">
                                        <div class="accordion-body">
                        <?php
                            echo '<table class="table text-center">';
                            echo '<thead>';
                                echo '<tr>';
                                echo '<th scope="col">Name</th>';
                                echo '<th scope="col">Control</th>';
                                echo '</tr>';
                                echo '</thead>';
                                echo '<tbody>';
                                echo '<tr>';
                                echo '<td>'.$subcat['SubName'].'</td>';
                                echo '<td><a href="categories.php?do=EditSub&catid='.$subcat['SID'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> <a href="categories.php?do=DeleteSub&catid='.$subcat['SID'].'" class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a></td><a href="categories.php?do=AddSubSub&subid='.$subcat['SID'].'" class="btn btn-outline-primary btn-sm"><i class="fa fa-plus"></i> Add Sub Sub Category</a>';
                                echo '</tr>';
                                echo '</tbody>';
                                echo '</table>';   
                                //echo $subcat['SID'].'<br>';
                                ///////////sub sub cat
                                $stmt4 = $con->prepare("SELECT * FROM subsubcategory WHERE SubSubID = ?");
                                $stmt4->execute(array($subcat['SID']));
                                $subsubcats = $stmt4->fetchAll();
                                $count = $stmt4->rowCount();
                                $k = 1024;     
                                foreach($subsubcats as $subsubcat){
                                    ?>
                                    <div class="container" >
                                        <div class="accordion" >
                                            <div class="accordion-item">
                                                <h6 class="accordion-header" id="panelsStayOpen-heading<?php echo $k; ?>">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse<?php echo $k; ?>" aria-expanded="false" aria-controls="panelsStayOpen-collapse<?php echo $k; ?>">
                                                    <?php echo $subsubcat['Name']; ?>
                                                </button>
                                                </h6>
                                                    <div id="panelsStayOpen-collapse<?php echo $k; ?>" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-heading<?php echo $k; ?>">
                                                    <div class="accordion-body">
                                    <?php
                                        echo '<table class="table text-center">';
                                        echo '<thead>';
                                            echo '<tr>';
                                            echo '<th scope="col">Name</th>';
                                            echo '<th scope="col">Control</th>';
                                            echo '</tr>';
                                            echo '</thead>';
                                            echo '<tbody>';
                                            echo '<tr>';
                                            echo '<td>'.$subsubcat['Name'].'</td>';
                                            echo '<td><a href="categories.php?do=EditSubSub&catid='.$subsubcat['SSID'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> <a href="categories.php?do=DeleteSubSub&catid='.$subsubcat['SSID'].'" class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a></td>';
                                            echo '</tr>';
                                            echo '</tbody>';
                                            echo '</table>';   
                                        echo '</div>';
                                        echo '</div>';
                                        echo '</div>';
                                        echo '</div>';
                                    echo '</div>';
                                    $k = $k +1;
                                }
                            //sub sub cat
                            echo '</div>';
                            echo '</div>';
                            echo '</div>';
                            echo '</div>';
                        echo '</div>';
                        $j = $j +1;
                    }
                    //sub sub cat 
                //sub cat
                    echo '</div>';
                echo '</div>';
            echo '</div>';
            $i = $i +1;
        }
            ?>
            <br>
            <!-- <div class="container" >
            <div class="accordion" >
            <div class="accordion-item">
                <h6 class="accordion-header" id="panelsStayOpen-heading<?php  ?>">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapse<?php  ?>" aria-expanded="false" aria-controls="panelsStayOpen-collapse<?php  ?>">
                    Accordion Item #2
                </button>
                </h6>
                <div id="panelsStayOpen-collapse<?php  ?>" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-heading<?php  ?>">
                <div class="accordion-body">
                    <strong>This is the second item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                </div>
                </div>
            </div>
            </div>
            </div> -->
        </div> 
        </div>
    </div>
    <?php }else 
    echo "</br><div class='container'> <div class='alert alert-info'>No Records to Display.</div></div>";
    echo '<div class="container catbtn"><a href="categories.php?do=Add" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add New Category</a></div>';
    ?> 
    <?php 
    }elseif($do == 'Add'){
        ?>
                   <div class="container">
            <h3 class="">Add New Category</h3>
                <form class="row g-3" action="?do=Insert" method="POST">  
                <div class="form-floating col-md-12">                    
                    <input type="text" name="name" class="form-control" id="floatingInput" placeholder="name" autocomplete="off">
                    <label for="floatingInput">Category Name</label>
                    <p><small>Insert Category Name</small></p>
                </div>
                <div class="form-floating col-md-12">
                    <textarea type="text" name="description" class="form-control" id="floatingInput" placeholder="description" autocomplete="new-passowrd" ></textarea>
                    <label for="floatingInput">Category Description</label>
                    <p><small>Insert Category Description</small></p>
                </div>
                <div class="col-12">
                    <div class="form-check">
                    <input class="form-check-input is-invalid" type="checkbox" id="invalidCheck3" >
                    <label class="form-check-label" for="invalidCheck3">
                        Upload User Information
                    </label>
                    <div class="invalid-feedback">
                        You must agree before submitting.
                    </div>
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit"class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add Category</button>
                </div>
                </form>
                </div>
        <?php
    }elseif($do == 'Insert'){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //get variables from form
            ?> <div class="container"><h3 class="">Insert Category</h3><?php
            $name = $_POST['name'];
            $desc = $_POST['description'];
            $order = $_POST['ordering'];
                //check if user exist in db
                $check = checkItem("name","categories",$name);
                if($check == 1){
                         // redirectHome($theMsg, $url = null, $seconds = 20)
                    $theMsg =  "<div class='alert alert-danger'>Category Exist, Try again.</div>";
                    redirectHome($theMsg,'categories.php?do=Add',1);  
                //insert member into database
                }elseif(empty($name)){
                    $theMsg =  "<div class='alert alert-danger'>Category name can not be empty, Try again.</div>";
                    redirectHome($theMsg,'categories.php?do=Add',1);  
                }elseif (strlen($name) < 4) {
                    $theMsg =  "<div class='alert alert-danger'>Category can not be less than 4 characcters, Try again.</div>";
                    redirectHome($theMsg,'categories.php?do=Add',1);  
                }
                else {
                    $stmt = $con->prepare("INSERT INTO categories(Name, Description) 
                    VALUES(:zname, :zdesc)");
                    $stmt->execute(array(
                        'zname' => $name, 
                        'zdesc' => $desc));
                    // redirectHome($theMsg, $url = null, $seconds = 20)
                    $theMsg =  "<div class='alert alert-success'>Category added.</div>";
                    redirectHome($theMsg,'categories.php',2);  
                }
        }else{
            ?> <div class="container"><?php
            // redirectHome($theMsg, $url = null, $seconds = 20)
            $theMsg =  "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,'index.php',5);
        }
        ?> </div><?php
    }elseif($do == 'Edit') {
        $catid = isset($_GET['catid']) && is_numeric($_GET['catid']) ? intval($_GET['catid']) : 0;
        $stmt = $con->prepare("SELECT * FROM categories WHERE ID = ?");
        $stmt->execute(array($catid));
        $cat = $stmt->fetch();
        $count = $stmt->rowCount();
        if($stmt->rowCount() > 0 ){
            ?>               
            <div class="container">
                <h3 class="">Edit Category</h3>
                    <form class="row g-3" action="?do=Update" method="POST">  
                        <input type="hidden" name="catid" value="<?php echo $catid ?>">
                    <div class="form-floating col-md-12">                    
                        <input type="text" name="name" class="form-control" id="floatingInput" placeholder="name" value="<?php echo $cat['Name']?>">
                        <label for="floatingInput">Category Name</label>
                        <p><small>Update Category Name</small></p>
                    </div>
                    <div class="form-floating col-md-12">
                        <textarea  type="text" name="description" class="form-control" id="floatingInput" placeholder="description" ><?php echo $cat['Description']?></textarea>
                        <label for="floatingInput">Category Description</label>
                        <p><small>Update Category Description</small></p>
                    </div>
                    <div class="col-12">
                        <div class="form-check">
                        <input class="form-check-input is-invalid" type="checkbox" id="invalidCheck3" >
                        <label class="form-check-label" for="invalidCheck3">
                            Upload User Information
                        </label>
                        <div class="invalid-feedback">
                            You must agree before submitting.
                        </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit"class="btn btn-outline-success"><i class="fa fa-edit"></i> Update Cahanges</button>
                    </div>
                    </form>         
                    </div>  
                 <?php
        }else{
            ?> <div class="container"><?php
            //redirectHome($theMsg,'members.php',5);
            $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,null,5);
            ?> </div><?php        
        }
    }elseif($do == 'Update') {
        ?> <div class="container">  
                <h3 class="">Update Category</h3><?php
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //get variables from form
            $id = $_POST['catid'];
            $name = $_POST['name'];
            $desc = $_POST['description'];
            $check = countItems("*", "categories", "WHERE Name = '$name' AND ID != $id");
            if($check == 1 ){
                $theMsg =  "<div class='alert alert-danger'>Category Exist, Try again.</div>";
                redirectHome($theMsg,'categories.php?do=Edit&catid='.$id.'',1);  
            }elseif(strlen($name) < 4 && strlen($name) !== 0){ 
                $theMsg =  "<div class='alert alert-danger'>Category can not be empty or less than 4 characcters, Try again.</div>";
                redirectHome($theMsg,'categories.php?do=Edit&catid='.$id.'',1);  
            }elseif(strlen($name) == 0){
                $theMsg =  "<div class='alert alert-danger'>Category can not be empty or less than 4 characcters, Try again.</div>";
                redirectHome($theMsg,'categories.php?do=Edit&catid='.$id.'',1);  
            }else {
                
                $stmt = $con->prepare("UPDATE categories SET Name = ?, Description = ? WHERE ID = ?");
                $stmt->execute(array($name, $desc, $id));
                //echo success message
                if($stmt->rowCount() > 0){
                   // redirectHome($theMsg, $url = null, $seconds = 20)
                    $theMsg = "<div class='alert alert-success  alert-dismissible fade show' role='alert'>Record Updated.</div>";
                    redirectHome($theMsg,'categories.php',5);
                }else{
                    $theMsg = "<div class='alert alert-secondary alert-dismissible fade show' role='alert'>Record not Updated.</div>";
                    redirectHome($theMsg,'categories.php',5);
                }
            }
        }else{
            $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,null,5);
        }
        ?> </div><?php
    }elseif ($do =='Delete') {
        ?> <div class="container">  
                    <h3 class="">Delete Category</h3>
            <?php
            $catid = isset($_GET['catid']) && is_numeric($_GET['catid']) ? intval($_GET['catid']) : 0;
            $check = checkItem('ID', 'categories',$catid );
            if($check == 1 ){
                $stmt = $con->prepare("DELETE FROM categories WHERE ID = :zcat");
                $stmt->bindParam(":zcat", $catid);
                $stmt->execute();
                //redirectHome($theMsg, $url = null, $seconds = 20)
                $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Record Deleted.</div>";
                redirectHome($theMsg, 'categories.php?do=Manage', 0.5);
            }else {
                // redirectHome($theMsg, $url = null, $seconds = 20)
                $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Invalid ID.</div>";
                redirectHome($theMsg, null, 5);
            ?> </div><?php
            }
                }
                /////////////sub
                elseif($do == 'AddSub'){
                    //echo $_GET['subid'];
                    ?>
                               <div class="container">
                        <h3 class="">Add New Sub Category</h3>
                            <form class="row g-3" action="?do=InsertSub&subid=<?php echo $_GET["subid"]?>" method="POST">  
                            <input type="hidden" name="subid" value='<?php echo $_GET["subid"]?>'>
                            <div class="form-floating col-md-12">                    
                                <input type="text" name="name" class="form-control" id="floatingInput" placeholder="name" autocomplete="off">
                                <label for="floatingInput">Category Name</label>
                                <p><small>Insert Sub Category Name</small></p>
                            </div>
                            <div class="form-floating col-md-12">
                                <textarea type="text" name="description" class="form-control" id="floatingInput" placeholder="description" autocomplete="new-passowrd" ></textarea>
                                <label for="floatingInput">Category Description</label>
                                <p><small>Insert Sub Category Description</small></p>
                            </div>
                            <div class="col-12">
                                <div class="form-check">
                                <input class="form-check-input is-invalid" type="checkbox" id="invalidCheck3" >
                                <label class="form-check-label" for="invalidCheck3">
                                    Upload User Information
                                </label>
                                <div class="invalid-feedback">
                                    You must agree before submitting.
                                </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit"class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add Category</button>
                            </div>
                            </form>
                            </div>
                    <?php
                
                }elseif($do == 'InsertSub'){
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        //get variables from form
                        ?> <div class="container"><h3 class="">Insert Sub Category</h3><?php
                        $subid = isset($_GET['subid']) && is_numeric($_GET['subid']) ? intval($_GET['subid']) : 0;
                        $name = $_POST['name'];
                        $desc = $_POST['description'];
                            //check if user exist in db
                            $check = checkItem("SubName","subcategory",$name);
                            if($check == 1){
                                   // redirectHome($theMsg, $url = null, $seconds = 20)
                                $theMsg =  "<div class='alert alert-danger'>Sub Category Exist, Try again.</div>";
                                redirectHome($theMsg,"categories.php?do=AddSub&subid=$subid",3);  
                            //insert member into database
                            }elseif(empty($name)){
                                $theMsg =  "<div class='alert alert-danger'>Category name can not be empty, Try again.</div>";
                                redirectHome($theMsg,"categories.php?do=AddSub&subid=$subid",3);  
                            }elseif (strlen($name) < 4) {
                                $theMsg =  "<div class='alert alert-danger'>Category can not be less than 4 characcters, Try again.</div>";
                                redirectHome($theMsg,"categories.php?do=AddSub&subid=$subid",3);  
                            }
                            else {
                                $stmt = $con->prepare("INSERT INTO subcategory(SubName, Description, SubID) 
                                VALUES(:zname, :zdesc,:zsubid)");
                                $stmt->execute(array(
                                    'zname' => $name, 
                                    'zdesc' => $desc, 
                                    'zsubid' => $subid));
                                // redirectHome($theMsg, $url = null, $seconds = 20)
                                $theMsg =  "<div class='alert alert-success'>Category added.</div>";
                                redirectHome($theMsg,'categories.php',3);  
                            }
                    }else{
                        ?> <div class="container"><?php
                        // redirectHome($theMsg, $url = null, $seconds = 20)
                        $theMsg =  "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
                        redirectHome($theMsg,'index.php',5);
                    }
                    ?> </div><?php
                }elseif($do == 'EditSub') {
                    $catid = isset($_GET['catid']) && is_numeric($_GET['catid']) ? intval($_GET['catid']) : 0;
                    $stmt = $con->prepare("SELECT * FROM subcategory WHERE SID = ?");
                    $stmt->execute(array($catid));
                    $cat = $stmt->fetch();
                    $count = $stmt->rowCount();
                    if($stmt->rowCount() > 0 ){                        
                        ?>               
                        <div class="container">
                            <h3 class="">Edit Sub Category</h3>
                                <form class="row g-3" action="?do=UpdateSub" method="POST">  
                                    <input type="hidden" name="catid" value="<?php echo $catid ?>">
                                <div class="form-floating col-md-12">                    
                                    <input type="text" name="name" class="form-control" id="floatingInput" placeholder="name" value="<?php echo $cat['SubName']?>">
                                    <label for="floatingInput">Category Name</label>
                                    <p><small>Update Sub Category Name</small></p>
                                </div>
                                <div class="form-floating col-md-12">
                                    <textarea  type="text" name="description" class="form-control" id="floatingInput" placeholder="description" ><?php echo $cat['Description']?></textarea>
                                    <label for="floatingInput">Category Description</label>
                                    <p><small>Update Sub Category Description</small></p>
                                </div>
                                <div class="col-12">
                                    <div class="form-check">
                                    <input class="form-check-input is-invalid" type="checkbox" id="invalidCheck3" >
                                    <label class="form-check-label" for="invalidCheck3">
                                        Upload User Information
                                    </label>
                                    <div class="invalid-feedback">
                                        You must agree before submitting.
                                    </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button type="submit"class="btn btn-outline-success"><i class="fa fa-edit"></i> Update Cahanges</button>
                                </div>
                                </form>         
                                </div>  
                             <?php
                    }else{
                        ?> <div class="container"><?php
                        //redirectHome($theMsg,'members.php',5);
                        $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
                        redirectHome($theMsg,null,5);
                        ?> </div><?php        
                    }
                }elseif($do == 'UpdateSub') {
                    ?> <div class="container">  
                            <h3 class="">Update Sub Category</h3><?php
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        //get variables from form
                        $id = $_POST['catid'];
                        $name = $_POST['name'];
                        $desc = $_POST['description'];
                        $check = countItems("*", "subcategory", "WHERE SubName = '$name' AND SID != $id");
                        if($check == 1 ){
                            $theMsg =  "<div class='alert alert-danger'>Sub Category Exist, Try again.</div>";
                            redirectHome($theMsg,'categories.php?do=EditSub&catid='.$id.'',3);  
                        }elseif(strlen($name) < 4 && strlen($name) !== 0){ 
                            $theMsg =  "<div class='alert alert-danger'>Category can not be empty or less than 4 characcters, Try again.</div>";
                            redirectHome($theMsg,'categories.php?do=EditSub&catid='.$id.'',3);  
                        }elseif(strlen($name) == 0){
                            $theMsg =  "<div class='alert alert-danger'>Category can not be empty or less than 4 characcters, Try again.</div>";
                            redirectHome($theMsg,'categories.php?do=EditSub&catid='.$id.'',3);  
                        }
                        else {
                            $stmt = $con->prepare("UPDATE subcategory SET SubName = ?, Description = ? WHERE SID = ?");
                            $stmt->execute(array($name, $desc, $id));
                            //echo success message
                            if($stmt->rowCount() > 0){
                               // redirectHome($theMsg, $url = null, $seconds = 20)
                                $theMsg = "<div class='alert alert-success  alert-dismissible fade show' role='alert'>Record Updated.</div>";
                                redirectHome($theMsg,'categories.php',3);
                            }else{
                                $theMsg = "<div class='alert alert-secondary alert-dismissible fade show' role='alert'>Record not Updated.</div>";
                                redirectHome($theMsg,'categories.php',3);
                            }
                        }
                    }else{
                        $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
                        redirectHome($theMsg,null,5);
                    }
                    ?> </div><?php
                }elseif ($do =='DeleteSub') {
                    ?> <div class="container">  
                                <h3 class="">Delete Sub Category</h3>
                        <?php
                        $catid = isset($_GET['catid']) && is_numeric($_GET['catid']) ? intval($_GET['catid']) : 0;
                        $check = checkItem('SID', 'subcategory',$catid );
                        if($check == 1 ){
                            $stmt = $con->prepare("DELETE FROM subcategory WHERE SID = :zcat");
                            $stmt->bindParam(":zcat", $catid);
                            $stmt->execute();
                            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Record Deleted.</div>";
                            redirectHome($theMsg, 'categories.php?do=Manage',5);
                                        /////////////sub
                        }
                        }elseif($do == 'AddSubSub'){                    
                    ?>
                               <div class="container">
                        <h3 class="">Add New Sub Sub Category</h3>
                            <form class="row g-3" action="?do=InsertSubSub&subid=<?php echo $_GET["subid"]?>" method="POST">  
                            <input type="hidden" name="subid" value='<?php echo $_GET["subid"]?>'>
                            <div class="form-floating col-md-12">                    
                                <input type="text" name="name" class="form-control" id="floatingInput" placeholder="name" autocomplete="off">
                                <label for="floatingInput">Category Name</label>
                                <p><small>Insert Sub Category Name</small></p>
                            </div>
                            <div class="form-floating col-md-12">
                                <textarea type="text" name="description" class="form-control" id="floatingInput" placeholder="description" autocomplete="new-passowrd" ></textarea>
                                <label for="floatingInput">Category Description</label>
                                <p><small>Insert Sub Category Description</small></p>
                            </div>
                            <div class="col-12">
                                <div class="form-check">
                                <input class="form-check-input is-invalid" type="checkbox" id="invalidCheck3" >
                                <label class="form-check-label" for="invalidCheck3">
                                    Upload User Information
                                </label>
                                <div class="invalid-feedback">
                                    You must agree before submitting.
                                </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit"class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add Category</button>
                            </div>
                            </form>
                            </div>
                    <?php
                }elseif($do == 'InsertSubSub'){
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        //get variables from form
                        ?> <div class="container"><h3 class="">Insert Sub Sub Category</h3><?php
                        $subid = isset($_GET['subid']) && is_numeric($_GET['subid']) ? intval($_GET['subid']) : 0;
                        $name = $_POST['name'];
                        $desc = $_POST['description'];
                            //check if user exist in db
                            $check = checkItem("Name","subsubcategory",$name);
                            if($check == 1){
                                   // redirectHome($theMsg, $url = null, $seconds = 20)
                                $theMsg =  "<div class='alert alert-danger'>Sub Sub Category Exist, Try again.</div>";
                                redirectHome($theMsg,"categories.php?do=AddSubSub&subid=$subid",3);  
                            //insert member into database
                            }elseif(empty($name)){
                                $theMsg =  "<div class='alert alert-danger'>Category name can not be empty, Try again.</div>";
                                redirectHome($theMsg,"categories.php?do=AddSubSub&subid=$subid",3);  
                            }elseif (strlen($name) < 4) {
                                $theMsg =  "<div class='alert alert-danger'>Category can not be less than 4 characcters, Try again.</div>";
                                redirectHome($theMsg,"categories.php?do=AddSubSub&subid=$subid",3);  
                            }
                            else {
                                $stmt = $con->prepare("INSERT INTO subsubcategory(Name, Description, SubSubID) 
                                VALUES(:zname, :zdesc,:zsubid)");
                                $stmt->execute(array(
                                    'zname' => $name, 
                                    'zdesc' => $desc, 
                                    'zsubid' => $subid));
                                // redirectHome($theMsg, $url = null, $seconds = 20)
                                $theMsg =  "<div class='alert alert-success'>Category added.</div>";
                                redirectHome($theMsg,'categories.php',3);  
                            }
                    }else{
                        ?> <div class="container"><?php
                        // redirectHome($theMsg, $url = null, $seconds = 20)
                        $theMsg =  "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
                        redirectHome($theMsg,'index.php',5);
                    }
                    ?> </div><?php
                }elseif($do == 'EditSubSub') {
                    $catid = isset($_GET['catid']) && is_numeric($_GET['catid']) ? intval($_GET['catid']) : 0;
                    $stmt = $con->prepare("SELECT * FROM subsubcategory WHERE SSID = ?");
                    $stmt->execute(array($catid));
                    $cat = $stmt->fetch();
                    $count = $stmt->rowCount();
                    if($stmt->rowCount() > 0 ){
                        ?>               
                        <div class="container">
                            <h3 class="">Edit Sub Sub Category</h3>
                                <form class="row g-3" action="?do=UpdateSubSub" method="POST">  
                                    <input type="hidden" name="catid" value="<?php echo $catid ?>">
                                <div class="form-floating col-md-12">                    
                                    <input type="text" name="name" class="form-control" id="floatingInput" placeholder="name" value="<?php echo $cat['Name']?>">
                                    <label for="floatingInput">Category Name</label>
                                    <p><small>Update Sub Category Name</small></p>
                                </div>
                                <div class="form-floating col-md-12">
                                    <textarea  type="text" name="description" class="form-control" id="floatingInput" placeholder="description" ><?php echo $cat['Description']?></textarea>
                                    <label for="floatingInput">Category Description</label>
                                    <p><small>Update Sub Category Description</small></p>
                                </div>
                                <div class="col-12">
                                    <div class="form-check">
                                    <input class="form-check-input is-invalid" type="checkbox" id="invalidCheck3" >
                                    <label class="form-check-label" for="invalidCheck3">
                                        Upload User Information
                                    </label>
                                    <div class="invalid-feedback">
                                        You must agree before submitting.
                                    </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button type="submit"class="btn btn-outline-success"><i class="fa fa-edit"></i> Update Cahanges</button>
                                </div>
                                </form>         
                                </div>  
                             <?php
                    }else{
                        ?> <div class="container"><?php
                        //redirectHome($theMsg,'members.php',5);
                        $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
                        redirectHome($theMsg,null,5);
                        ?> </div><?php        
                    }
                }elseif($do == 'UpdateSubSub') {
                    ?> <div class="container">  
                            <h3 class="">Update Sub Sub Category</h3><?php
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        //get variables from form
                        $id = $_POST['catid'];
                        $name = $_POST['name'];
                        $desc = $_POST['description'];
                        $check = countItems("*", "subsubcategory", "WHERE Name = '$name' AND SSID != $id");
                        if($check == 1 ){
                            $theMsg =  "<div class='alert alert-danger'>Sub Category Exist, Try again.</div>";
                            redirectHome($theMsg,'categories.php?do=EditSubSub&catid='.$id.'',3);  
                        }elseif(strlen($name) < 4 && strlen($name) !== 0){ 
                            $theMsg =  "<div class='alert alert-danger'>Category can not be empty or less than 4 characcters, Try again.</div>";
                            redirectHome($theMsg,'categories.php?do=EditSubSub&catid='.$id.'',3);  
                        }elseif(strlen($name) == 0){
                            $theMsg =  "<div class='alert alert-danger'>Category can not be empty or less than 4 characcters, Try again.</div>";
                            redirectHome($theMsg,'categories.php?do=EditSubSub&catid='.$id.'',3);  
                        }
                        else {
                            $stmt = $con->prepare("UPDATE subsubcategory SET Name = ?, Description = ? WHERE SSID = ?");
                            $stmt->execute(array($name, $desc, $id));
                            //echo success message
                            if($stmt->rowCount() > 0){
                               // redirectHome($theMsg, $url = null, $seconds = 20)
                                $theMsg = "<div class='alert alert-success  alert-dismissible fade show' role='alert'>Record Updated.</div>";
                                redirectHome($theMsg,'categories.php',3);
                            }else{
                                $theMsg = "<div class='alert alert-secondary alert-dismissible fade show' role='alert'>Record not Updated.</div>";
                                redirectHome($theMsg,'categories.php',3);
                            }
                        }                    
                    }else{
                        $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
                        redirectHome($theMsg,null,5);
                    }
                    ?> </div><?php
                }elseif ($do =='DeleteSubSub') {
                    ?> <div class="container">  
                                <h3 class="">Delete Sub Category</h3>
                        <?php
                        $catid = isset($_GET['catid']) && is_numeric($_GET['catid']) ? intval($_GET['catid']) : 0;
                        $check = checkItem('SSID', 'subsubcategory',$catid );
                        if($check == 1 ){
                            $stmt = $con->prepare("DELETE FROM subsubcategory WHERE SSID = :zcat");
                            $stmt->bindParam(":zcat", $catid);
                            $stmt->execute();
                            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Record Deleted.</div>";
                            redirectHome($theMsg, 'categories.php?do=Manage',5);
                        }
                    }else {
                            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Invalid ID.</div>";
                            redirectHome($theMsg, null, 5);
                        ?> </div><?php
                        }
    include $tpl . 'footer.php';
    
}else {
        header('location: index.php');
        exit();
}
ob_end_flush();