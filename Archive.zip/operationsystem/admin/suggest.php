<?php
$peoplep[]="ahmad";
$peoplep[]="bana";
$peoplep[]="bbb";
$peoplep[]="d";
$peoplep[]="e";
$peoplep[]="f";
$peoplep[]="g";
$q = $_REQUEST['q'];
$suggestion = "";
if($q != ""){
    $q = strtolower($q);
    $len = strlen($q);
    foreach($peoplep as $person){
        if(stristr($q, substr($person, 0,$len))){
            if($suggestion === ""){
                $suggestion = $person;
            }else {
                $suggestion .= ". $person";
            }

        }
    }
}
echo $suggestion === "" ? "No Data": $suggestion;
