<?php
/* 
**title function that echo page tirle in case the page has the variable pagetitle and echo the default for other pages
*/

function getTitle(){

    global $pageTitle;

    if(isset($pageTitle)){

        echo $pageTitle;

    }else{
        
        echo 'Default';
    }
}

/* redirect function*/
/* function parameters: error message, time(seconds), */
function redirectHome($theMsg, $url = null, $seconds = 20){

    if ($url === null){

        $url = 'index.php';
    }
    // }else {
    //     $url = $_SERVER['HTTP_REFERER'];
    // }
    echo $theMsg;
    
    echo "<div class='alert alert-info'>You will be directed after $seconds seconds..</div><br>

            <div class='text-center'>
                <div class='spinner-grow' style='width: 3rem; height: 3rem;' role='status'>
                    <span class='sr-only'>Loading...</span>
                </div>
            </div>";

    header("refresh:$seconds;url=$url");
    exit();
}
/*
*
*
*
*/
function checkItem($select, $from, $value){
    global $con;
    $statement = $con->prepare("SELECT $select FROM $from WHERE $select = ?");
    $statement->execute(array($value));
    $count = $statement->rowCount();
    return $count;
}
// count number of items
//count number of rows
function countItems($item, $table, $where = null){

    if($where === null){
        $where = '';
    }
        global $con;
        $stmt2 = $con->prepare("SELECT COUNT($item) FROM $table $where");
        $stmt2->execute();
        return $stmt2->fetchColumn();   
}

/*latest records from database, */
function getLatest($select, $table, $where = null ,$order, $limit = 5){
    global $con;
    if($where === null){
        $where = '';
    }
    $getStmt = $con->prepare("SELECT $select FROM $table $where ORDER BY $order DESC LIMIT $limit");
    $getStmt->execute();
    $rows = $getStmt->fetchAll();
    return $rows;
}