        
        <!-- <div class="navbar fixed-bottom">
        <footer class="footer mt-auto py-3 bg-light ">
            <div class="container">
                <span class="text-muted">&copy; NovaitSystems 2010–2021</span>
            </div>
        </footer> 
        <footer class="bg-light text-center text-lg-start">
        Copyright
            <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            excellencetech © 2021 Copyright:
                <a class="text-dark" href="#">excellencetech.com</a>
            </div>
        Copyright -->
        </footer>
        </div>
        <script src="<?php echo $js; ?>jquery-3.6.0.min.js"></script>
        <script src="<?php echo $js; ?>bootstrap.min.js"></script>
        <script src="<?php echo $js; ?>front.js"></script>        
    </body>
</html>

