<?php

function lang($phrase){
    static $lang = array(
        'welcome'=>'اهلا',
        'to'=>'في',
        'homepage'=>'صفحة الرئيسية'
    );
    return $lang[$phrase];
}