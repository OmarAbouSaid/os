<?php
/* manage member's page: add, edit, <delete></delete>
edit delete approve
*/
session_start();
if(isset($_SESSION['Username'])){

    $pageTitle = 'Comments';

    include 'init.php';

    $do = isset($_GET['do']) ? $_GET['do'] : 'Manage';
        //start manage page
    if($do == 'Manage'){
        
        $stmt = $con->prepare("SELECT 
        comments.*, items.Name 
        AS item_name, users.Username 
    FROM comments 
        INNER JOIN items 
        ON items. Item_ID = comments. item_id 
        INNER JOIN users 
        ON users.UserID = comments.user_id");
        $stmt->execute();
        $rows = $stmt->fetchAll();
        $count = $stmt->rowCount();

        if($stmt->rowCount() > 0 ){

        ?>                        
    <div class="container">       
        
     <h3 class="">Manage Comments</h3>
        
        <table class="table table-striped table-hover text-center table-bordered">
          <thead>
          <tr>
            <th scope="col">#ID</th>
            <th scope="col">Comment</th>
            <th scope="col">Comment Date</th>
            <th scope="col">Item</th>
            <th scope="col">Username</th>
            <th scope="col">Control</th>
          </tr>
          
          </thead>
          <tbody>    
              <?php 
                $i =1;
              foreach($rows as $row){
                  echo '<tr>';
                    echo '<td>'. $row['c_id'] .'</td>';
//comment start
                    if (empty($row['comment'])){
                        echo '<td><em>No Comment Added</em></td>';
                    }elseif (strlen($row['comment']) <= 12 && strlen($row['comment']) != 0) {
                        echo '<td>'. $row['comment'] .'</td>';
                    }else{
                    echo '<td><div class="d-inline-block text-truncate" style="max-width: 100px;">'. $row['comment'] .'</div>
                    <!-- Button trigger modal -->
                    <a  class="link-primary" data-bs-toggle="modal" data-bs-target="#exampleModal'.$i.'">
                        Read More..
                    </a>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal'.$i.'" tabindex="-'.$i.'" aria-labelledby="exampleModal'.$i.'Label" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                        <h6>'. $row['Username'] .' Comment on '.$row['item_name'].' Item</h6>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        '. $row['comment'] .'
                        </div>    
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>                      
                        </div>
                    </div>
                    </div>                                                                
                    </td>';}

//comment end   
                    
                    
                    echo '<td>'. $row['comment_date'] .'</td>';                                    
                    echo '<td>'. $row['item_name'] .'</td>';
                    echo '<td>'. $row['Username'] .'</td>';
                    echo '<td><a href="comments.php?do=Edit&commentid='.$row['c_id'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> 
                            <a href="comments.php?do=Delete&commentid='.$row['c_id'].'" class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a> ';
                        if($row['status'] == 0){
                            echo ' <a href="comments.php?do=Approve&commentid='.$row['c_id'].'" class="btn btn-outline-info btn-sm"><i class="fa fa-check"></i> Approve</a>';
                        }
                    echo '</td>';
                  echo '</tr> ';
                  $i = $i + 1;
              }
              ?>                                            
          </tbody>
        </table>
        <?php }else 
                echo "</br><div class='container'> <div class='alert alert-info'>No Records to Display.</div></div>";
                ?> 
        </div>
<?php 
    }elseif($do == 'Add'){
      
    }elseif($do == 'Insert'){        
        
    }elseif($do == 'Edit'){
        
        $commentid = isset($_GET['commentid']) && is_numeric($_GET['commentid']) ? intval($_GET['commentid']) : 0;

        $stmt = $con->prepare("SELECT * FROM comments WHERE c_id = ? LIMIT 1");
        $stmt->execute(array($commentid));
        $row = $stmt->fetch();
        $count = $stmt->rowCount();

        if($stmt->rowCount() > 0 ){

            /* */
            ?>               
            <div class="container">
            <h3 class="">Edit Comment</h3>
                <form class="row g-3" action="?do=Update" method="POST">  
                    <input type="hidden" name="commentid" value="<?php echo $commentid; ?>">             
                
                <div class="form-floating col-md-12">
                    <textarea type="text" name="comment" class="form-control" id="floatingInput" placeholder="fullname" required="required"><?php echo $row['comment']?></textarea>
                    <label for="floatingInput">Current Comment</label>
                    
                </div>
                <div class="col-12">
                    <div class="form-check">
                    <input class="form-check-input is-invalid" type="checkbox" id="invalidCheck3" required>
                    <label class="form-check-label" for="invalidCheck3">
                        Update User Information
                    </label>
                    <div class="invalid-feedback">
                        You must agree before submitting.
                    </div>
                    </div>
                </div>
                <div class="col-12">
                <button type="submit"class="btn btn-outline-success"><i class="fa fa-edit"></i> Update Changes</button>
                </div>
                </form>
                </div>
                 <?php
            /**/ 

        }else{
            ?> <div class="container"><?php
            //redirectHome($theMsg,'members.php',5);
            $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,null,2);
            ?> </div><?php
        }
        
    }elseif($do == 'Update'){//update page
        ?> <div class="container">  
                <h3 class="">Update Comment</h3><?php
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //get variables from form
            $id = $_POST['commentid'];
            $comment = $_POST['comment'];
            //validate the form
            $formErrors = array();

                if(strlen($comment) < 1 && strlen($comment) != 0){ $formErrors[] ='Comment can not be less than one characcters.';}                                   
                if(strlen($comment) > 200){ $formErrors[] ='Comment can not be more than 100 characcters.';}
                if(empty($comment)){ $formErrors[] ='Comment can not be empty.';}

            foreach ($formErrors as $error){
                $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">'.$error.'</div>';
                redirectHome($theMsg, 'comments.php?do=Edit&commentid='.$id.'', 2);
            }

            //update database with new info if there is no errors
            if (empty($formErrors)){

                //echo $id . $user . $email . $name;
                $stmt = $con->prepare("UPDATE comments SET comment = ? WHERE c_id = ?");
                $stmt->execute(array($comment, $id));
                //echo success message
                if($stmt->rowCount() > 0){
                   // redirectHome($theMsg, $url = null, $seconds = 20)
                    $theMsg = "<div class='alert alert-success  alert-dismissible fade show' role='alert'>Record Updated.</div>";
                    redirectHome($theMsg,'comments.php',5);
        
                    
                }else{
                   
                    $theMsg = "<div class='alert alert-secondary alert-dismissible fade show' role='alert'>Record not Updated.</div>";
                    redirectHome($theMsg,'comments.php',5);

                }
            }

        }else{
            $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,null,5);
        }
        ?> </div><?php

    }elseif($do == 'Delete'){
        ?> <div class="container">  
                <h3 class="">Delete Comment</h3>
        <?php
        $commentid = isset($_GET['commentid']) && is_numeric($_GET['commentid']) ? intval($_GET['commentid']) : 0;


        $check = checkItem('c_id', 'comments',$commentid );
     

        if($check == 1 ){
            
            $stmt = $con->prepare("DELETE FROM comments WHERE c_id = :zid");

            $stmt->bindParam(":zid", $commentid);

            $stmt->execute();

             //redirectHome($theMsg, $url = null, $seconds = 20)

            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Record Deleted.</div>";

            redirectHome($theMsg, 'comments.php?do=Manage', 2);

        }else {
            // redirectHome($theMsg, $url = null, $seconds = 20)

            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Invalid ID.</div>";
            redirectHome($theMsg, null, 2);
        ?> </div><?php
        }
        
    }elseif($do == 'Approve'){
        ?> <div class="container">  
                <h3 class="">Approve Comment</h3>
        <?php

        $commentid = isset($_GET['commentid']) && is_numeric($_GET['commentid']) ? intval($_GET['commentid']) : 0;


        $check = checkItem('c_id', 'comments',$commentid );
     

        if($check == 1 ){
            
            $stmt = $con->prepare("UPDATE comments SET status = 1 WHERE c_id =?");

            $stmt->execute(array($commentid));

             //redirectHome($theMsg, $url = null, $seconds = 20)

            $theMsg = "<div class='alert alert-info  alert-dismissible fade show' role='alert'>Comment Approved.</div>";

            redirectHome($theMsg, 'comments.php?do=Manage', 2);

        }else {
            // redirectHome($theMsg, $url = null, $seconds = 20)

            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Invalid ID.</div>";
            redirectHome($theMsg, null, 5);
        ?> </div><?php
        }
    }

    

    include $tpl.'footer.php';

}else{
    // echo 'You Are Not Authorized To Brows This Page';

    header('Location: index.php');

    exist();
}
