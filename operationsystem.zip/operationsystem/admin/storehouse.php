<?php

ob_start();
session_start();
$pageTitle = 'Storehouse';

if(isset($_SESSION['Username'])){
    include 'init.php';
    $do = isset($_GET['do']) ? $_GET['do']: 'Manage';
    if($do == 'Manage'){
        $stmt = $con->prepare("SELECT * FROM store");
        $stmt->execute();
        $stores = $stmt->fetchAll();
        if($stmt->rowCount() > 0 ){
        ?>                        
    <div class="container">       
     <h3 class="">Manage Storehouse</h3>
        <table class="table table-striped table-hover text-center table-bordered">
          <thead>
          <tr>
            <th scope="col">#ID</th>
            <th scope="col">Name</th>
            <th scope="col">Address</th>
            <th scope="col">Contact Number</th>
            <th scope="col">Control</th>
          </tr>
          <!-- Scrollable modal -->
          </thead>
          <tbody>    
              <?php 
              
              foreach($stores as $store){
                  echo '<tr>';
                    echo '<td>'. $store['store_id'] .'</td>';
                    echo '<td>'. $store['store_name'] .'</td>';
                    echo '<td>'. $store['store_address'] .'</td>';
                    echo '<td>'. $store['contact_number'] .'</td>';
                    echo '<td><a href="storehouse.php?do=Edit&storeid='.$store['store_id'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> 
                            <a href="storehouse.php?do=Delete&storeid='.$store['store_id'].'"class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a> ';
                    echo '</td>';
                  echo '</tr> ';
                  
              }
              ?>                                            
          </tbody>
        </table>
        </div>
        <?php }else 
    echo "</br><div class='container'> <div class='alert alert-info'>No Records to Display.</div></div>";
    echo '<div class="container"><a href="storehouse.php?do=Add" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add New Storehouse</a></div>';
    ?> 

<?php
    }elseif($do == 'Add'){
        //add members page
        ?>               
            <div class="container">
            <h3 class="">Add New Storehouse</h3>
                <form class="row g-3" action="?do=Insert" method="POST">  
                
                <div class="form-floating col-md-3">
                    <input type="text" name="name" class="form-control" id="floatingInput" placeholder="Item Name" autocomplete="off">
                    <label for="floatingInput">Storehouse Name</label>
                    <p><small>Insert Storehouse Name</small></p>
                </div>
                <div class="form-floating col-md-12">
                    <textarea type="text" name="address" class="form-control" id="floatingInput" placeholder="description" autocomplete="new-passowrd" ></textarea>
                    <label for="floatingInput">Storehouse Address</label>
                    <p><small>Insert Storehouse Address</small></p>
                </div>
                <div class="form-floating col-md-3">
                    <input type="number" name="number" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Storehouse Contact Number</label>
                    <p><small>Storehouse Contact Number</small></p>
                </div>                
                <div class="col-12">
                    <button type="submit"class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add Storehouse</button>
                </div>
                </form>
                 <?php    
    }elseif($do == 'Insert'){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //get variables from form
            ?> <div class="container"><h3 class="">Insert Item</h3><?php
            $name = $_POST['name'];
            $address = $_POST['address'];
            $number = $_POST['number'];
                $formErrors = array();
                    if(strlen($name) < 4 && strlen($name) != 0){ $formErrors[] ='Storehouse Name can not be less than 4 characcters.';}                                   
                    if(strlen($name) > 20){ $formErrors[] ='Storehouse Name can not be more than 20 characcters.';}
                    if(empty($name)){ $formErrors[] ='Storehouse Name can not be empty.';}
                    if(empty($address)){ $formErrors[] ='Storehouse Address can not be empty.';}
                    if(empty($number)){ $formErrors[] ='Storehouse Contact Number can not be empty.';}

                    foreach ($formErrors as $error){
                        //redirectHome($theMsg, $url = null, $seconds = 20)
                        $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">'.$error.'</div>';
                        redirectHome($theMsg, 'storehouse.php?do=Add', 2);                        
                    }             
            //update database with new info if there is no errors
            if (empty($formErrors)){
               // echo 'insert member into database';
                 $stmt = $con->prepare("INSERT INTO store(store_name, store_address, contact_number) 
                 VALUES(:zname, :zaddress, :znumber)");
                 $stmt->execute(array('zname' => $name, 'zaddress' => $address, 'znumber'=>$number));
                 $theMsg =  "<div class='alert alert-success'>Storehouse added.</div>";
                 redirectHome($theMsg,'storehouse.php',3);  
            }
        }else{
            ?> <div class="container"><?php
            // redirectHome($theMsg, $url = null, $seconds = 20)
            $theMsg =  "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,'index.php',2);
        }
        ?> </div><?php
    }elseif($do == 'Edit') {
        $storeid = isset($_GET['storeid']) && is_numeric($_GET['storeid']) ? intval($_GET['storeid']) : 0;
        $stmt = $con->prepare("SELECT * FROM store WHERE store_id = ?");
        $stmt->execute(array($storeid));
        $store = $stmt->fetch();
        $count = $stmt->rowCount();
        if($stmt->rowCount() > 0 ){
            /* */
            ?>               
            <div class="container">
            <h3 class="">Edit Storehouse</h3>
                <form class="row g-3" action="?do=Update" method="POST">  
                <input type="hidden" name="storeid" value="<?php echo $storeid; ?>">  
                <div class="form-floating col-md-4">
                    <input type="text" name="name" value="<?php echo $store['store_name'] ?>" class="form-control" id="floatingInput" placeholder="Item Name" autocomplete="off">
                    <label for="floatingInput">Storehouse Name</label>
                    <p><small>Update Storehouse Name</small></p>
                </div>
                <div class="form-floating col-md-12">
                    <textarea type="text" name="address" class="form-control" id="floatingInput" placeholder="description" autocomplete="new-passowrd" ><?php echo $store['store_address'] ?></textarea>
                    <label for="floatingInput">Storehouse Address</label>
                    <p><small>Update Storehouse Address</small></p>
                </div>
                <div class="form-floating col-md-6">
                    <input type="number" name="number" value="<?php echo $store['contact_number'] ?>" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Storehouse Contact Number</label>
                    <p><small>Update Storehouse Contact Number</small></p>
                </div>                
                <div class="col-12">
                    <button type="submit"class="btn btn-outline-success"><i class="fa fa-edit"></i> Update Changes</button>
                </div>
                </form>
        </div>
        <?php 
        }else{
            ?> <div class="container"><?php
            //redirectHome($theMsg,'members.php',5);
            $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,null,2);
            ?> </div><?php
        }
    }elseif($do == 'Update') {
                    ?> <div class="container">  
                    <h3 class="">Update Item</h3><?php
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                //get variables from form
                $storeid = $_POST['storeid'];
                $name = $_POST['name'];
                $address = $_POST['address'];
                $number = $_POST['number'];
                
                $formErrors = array();
                if(strlen($name) < 4 && strlen($name) != 0){ $formErrors[] ='Storehouse Name can not be less than 4 characcters.';}                                   
                if(strlen($name) > 20){ $formErrors[] ='Storehouse Name can not be more than 20 characcters.';}
                if(empty($name)){ $formErrors[] ='Storehouse Name can not be empty.';}
                if(empty($address)){ $formErrors[] ='Storehouse Address can not be empty.';}
                if(empty($number)){ $formErrors[] ='Storehouse Contact Number can not be empty.';}

                    foreach ($formErrors as $error){
                        //redirectHome($theMsg, $url = null, $seconds = 20)
                        $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">'.$error.'</div>';
                        redirectHome($theMsg, 'storehouse.php?do=Edit&storeid='.$storeid.'', 2);
                    }
                if (empty($formErrors)){
                    $stmt = $con->prepare("UPDATE store 
                    SET 
                    store_name = ?, store_address = ?, contact_number = ?
                    WHERE store_id = ?");
                    $stmt->execute(array($name, $address, $number, $storeid));
                    if($stmt->rowCount() > 0){
                    // redirectHome($theMsg, $url = null, $seconds = 20)
                        $theMsg = "<div class='alert alert-success  alert-dismissible fade show' role='alert'>Record Updated.</div>";
                        redirectHome($theMsg,'storehouse.php',2);
                    }else{
                        $theMsg = "<div class='alert alert-secondary alert-dismissible fade show' role='alert'>Record not Updated.</div>";
                        redirectHome($theMsg,'storehouse.php',2);
                    }
                }
            }else{
                $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
                redirectHome($theMsg,null,5);
            }
            ?> </div><?php
    }elseif($do == 'Delete') {
        ?> <div class="container">  
                <h3 class="">Delete Storehouse</h3>
        <?php
        $storeid = isset($_GET['storeid']) && is_numeric($_GET['storeid']) ? intval($_GET['storeid']) : 0;
        $check = checkItem('store_id', 'store',$storeid );
        if($check == 1 ){
            $stmt = $con->prepare("DELETE FROM store WHERE store_id = :zstore");
            $stmt->bindParam(":zstore", $storeid);
            $stmt->execute();
            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Record Deleted.</div>";
            redirectHome($theMsg, 'storehouse.php?do=Manage', 2);
        }else {
            // redirectHome($theMsg, $url = null, $seconds = 20)
            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Invalid ID.</div>";
            redirectHome($theMsg, null, 2);
        ?> </div><?php
        }
    }
    include $tpl . 'footer.php';
    
}else {
        header('location: index.php');
        exit();
}
ob_end_flush();