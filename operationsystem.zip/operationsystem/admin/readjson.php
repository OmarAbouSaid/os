<?php
$items = json_decode($_POST['emp'], true);
//print_r($items);
foreach($item as $items){
    print_r($items['name']);
}
?>
