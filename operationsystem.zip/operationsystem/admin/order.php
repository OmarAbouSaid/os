<?php

ob_start();
session_start();
$pageTitle = '';

if(isset($_SESSION['Username'])){
    include 'init.php';


    $stmt = $con->prepare("SELECT 
    items.*, subsubcategory.Name 
    AS category_name, users.Username, store.store_name 
FROM items 
    INNER JOIN subsubcategory 
    ON subsubcategory.SSID = items.Cat_ID 
    INNER JOIN users 
    ON users.UserID = items.Member_ID
    INNER JOIN store 
    ON store.store_id = items.Store_ID");
$stmt->execute();
$items = $stmt->fetchAll();


?>
<div class="container">
    <br>
<div class="card">
  <div class="card-header">
    New Orders
  </div>
  <div class="card-body">
    <form>
        <div class="form-group row">
            <label class="col-sm-3" alighn="right">Order Date</label>
            <div class="col-sm-6">
                <input type="text" readonly class="form-control form-control-sm" value="<?php echo date("d/m/y");?>">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3" alighn="right">Customer Name</label>
            <div class="col-sm-6">
                <input type="text" class="form-control form-control-sm" >
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h4>Order List</h4>



                <table class="table table-striped table-hover text-center table-bordered">
          <thead>
          <tr>
            <th scope="col">#ID</th>
            <th scope="col">Name</th>
            <th scope="col">Price</th>
            <th scope="col">Available Quantity</th>
            <th scope="col">Storehouse</th>
            <th scope="col">Required Quantity</th>
            <th scope="col"></th>
          </tr>
          <!-- Scrollable modal -->
          </thead>
          <tbody>    
              <?php 
              foreach($items as $item){
                  echo '<tr>';
                    echo '<td>'. $item['Item_ID'] .'</td>';
                    echo '<td>'. $item['Name'] .'</td>';
                    echo '<td>'. $item['price'] .'</td>'; 
                    echo '<td id="quantity-'.$item['Item_ID'].'">'. $item['quantity'] .'</td>'; 
                    echo '<td>'. $item['store_name'] .'</td>';
                    echo '<td><input value="1" min="1" onchange="changeQuantity('.$item['Item_ID'].', '.$item['quantity'].' , this.value)" id="input-'.$item['Item_ID'].'" type="number"></td>';
                    echo '<td><button onclick="addToMyItem('.$item['Item_ID'].', `'.$item['Name'].'`, '.$item['price'].')" id="add" class="btn btn-outline-success">Add</button>';
                    echo '</td>';
                  echo '</tr> ';
              }
              ?>                                            
          </tbody>
        </table>
                <hr>
       
        <table class="table table-striped table-hover text-center table-bordered">
          <thead>
          <tr>
            <th scope="col">#ID</th>
            <th scope="col">Name</th>
            <th scope="col">Price</th>
            <th scope="col">Total</th>
            <th scope="col">Quantity</th>
            <th scope="col">Action</th>
          </tr>
          </thead>
          <tbody id="buyTable">    
                                           
          </tbody>
        </table>
        <div>Total amount: <span id="total"><span></div>
        <div>Total sets : <span id="totalQuantity"><span></div>
        <div>Total item : <span id="totalItem"><span></div>
       

        
            </div>
        </div>
        <!--  -->
        <br>
        <hr>
        <br>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" alighn="right" for="sub_total">Discount</label>
            <div class="col-sm-6">
                <input   type="number" name="sub_total" class="form-control form-control-sm" id="discount" onchange="onDiscount(this.value)" required >
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" alighn="right" for="sub_total">Delevery Fees</label>
            <div class="col-sm-6">
                <input  value="0" type="number" name="sub_total" class="form-control form-control-sm" id="discount" onchange="onFees(this.value)" required >
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-3 col-form-label" alighn="right" for="due">Paid</label>
            <div class="col-sm-6">
                <input type="text" name="due" id="subTotal" class="form-control form-control-sm" readonly required>
            </div>
        </div>
        </form>

            </div>
        </div>
        <center><button id="target" type="submit" class="btn btn-info" > Order</button></center> 

   

</div>
</div>
</div>

<script src="layout/js/jquery-3.6.0.min.js"></script>
<script>
var myItems = [];
var Total = 0, TotalQuantity = 0, totalItem = 0, subTotal = 0, fees = 0;
function changeQuantity(id, total, value){
    if(total - value >= 0){
        document.getElementById(`quantity-${id}`).innerText= total - value;
    }else{
        document.getElementById(`quantity-${id}`).innerText= 0;
        document.getElementById(`input-${id}`).value= total;
    }
}
function addToMyItem(id, name, price){
    var quantity = document.getElementById(`input-${id}`).value;
    var founded = myItems.filter(el => el.id == id);
    if(founded.length == 0){
        myItems.push({
        'id': id,
        'name': name,
        'price': price,
        'total': quantity*price,
        'quantity': quantity, 
    });
    }else{
        alert('this item added before soory !')
    }
    fetchData();
}
function deleteFromMyItem(id){
    myItems = myItems.filter(el => el.id != id);
    fetchData();
};
function fetchData(){
    Total = 0;
    totalItem = 0;
    TotalQuantity = myItems.length;
    document.getElementById(`buyTable`).innerHTML = "";
    myItems.forEach(el => {
        Total += el.total;
        totalItem += +el.quantity;
        document.getElementById(`buyTable`).innerHTML += `<tr>
        <td> ${el.id} </td>
        <td> ${el.name} </td>
        <td> ${el.price} </td>
        <td> ${el.total} </td>
        <td> ${el.quantity} </td>
        <td> <button onclick="deleteFromMyItem(${el.id})" class="btn btn-outline-danger">Remove</button> </td>
        </tr>`            
    });
    subTotal = Total;
    document.getElementById(`totalQuantity`).innerText = TotalQuantity;
    document.getElementById(`totalItem`).innerText = totalItem;
    document.getElementById(`total`).innerText = Total;
    
}
function onDiscount(val){
    subTotal = Total - ((val * Total) / 100); 
    document.getElementById(`subTotal`).value = subTotal;
}
function onFees(fees){
    fees = fees;
    Total = +fees + +subTotal;
    document.getElementById(`subTotal`).value = Total
}




$(document).ready(function() {
    $( "#target" ).click(function() {
        //console.log(myItems);
$.ajax({
    url: "readjson.php",
    method: "post",
    data: {emp: JSON.stringify (myItems)}, fees,
    success: function(res){
        console.log(res);
    }

});

});
});

</script>
<?php


include $tpl . 'footer.php';
    
}else {
        header('location: index.php');
        exit();
}


ob_end_flush();