<?php

ob_start();
session_start();
$pageTitle = '';

if(isset($_SESSION['Username'])){
    include 'init.php';




?>
<div class="container">
    <br>
<div class="card">
  <div class="card-header">
    New Orders
  </div>
  <div class="card-body">
    <form>
        <div class="form-group row">
            <label class="col-sm-3" alighn="right">Order Date</label>
            <div class="col-sm-6">
                <input type="text" readonly class="form-control form-control-sm" value="<?php echo date("d/m/y");?>">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-3" alighn="right">Customer Name</label>
            <div class="col-sm-6">
                <input type="text" class="form-control form-control-sm" >
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h4>Order List</h4>
                <table class="table table-striped table-hover text-center table-bordered">
        <thead>
        <tr>
        <th scope="col">#</th>
        <th scope="col">Item Number</th>
        <th scope="col">Total Quantity</th>
        <th scope="col">Quantity</th>
        <th scope="col">Price</th>
        <th scope="col">Total</th>
        </tr>
        <!-- Scrollable modal -->
        </thead>
        <tbody id="invoice-item">    
        <tr>
        <td><b id="number">1</b></td>
        <td>
            <select name="pid[]" class="form-control form-control-sm" required>
                <option>Washing Machine</option>
            </select>
        </td>
        <td><input name="tqty[]" type="text" class="form-control form-control-sm" readonly></td>

        <td><input name="qty[]" type="text" class="form-control form-control-sm" required></td>
        <td><input name="price[]" type="text" class="form-control form-control-sm" readonly></td>
        <td> SYP</td>
        </tr> 
        </tbody>
        </table>
        <center>
            <button id="add" class="btn btn-success"> Add

            </button>
            <button id="remove" class="btn btn-danger"> Remove

            </button>
        </center>
            </div>
        </div>
    </form>
</div>
</div>
</div>
<?php



    include $tpl . 'footer.php';
    
}else {
        header('location: index.php');
        exit();
}


ob_end_flush();