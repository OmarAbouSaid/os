<?php
/* manage member's page: add, edit, <delete></delete>
*/
session_start();
if(isset($_SESSION['Username']) && ($_SESSION['GroupID'] == 1 || $_SESSION['GroupID'] == 2)  ){

    $pageTitle = 'Members';

    include 'init.php';

    $do = isset($_GET['do']) ? $_GET['do'] : 'Manage';
        //start manage page
    if($do == 'Manage'){

        if($_SESSION['GroupID'] == 2){
        $stmt = $con->prepare("SELECT * FROM users WHERE GroupID != 1 ");
        $stmt->execute();
        $rows = $stmt->fetchAll();
        $count = $stmt->rowCount();

        if($stmt->rowCount() > 0 ){
        ?>                        
    <div class="container">       
        
     <h3 class="">Manage Users</h3>
        
        <table class="table table-striped table-hover text-center table-bordered">
          <thead>
          <tr>
            <th scope="col">#ID</th>
            <th scope="col">Username</th>
            <th scope="col">Position</th>

            <th scope="col">Email</th>
            <th scope="col">Full Name</th>
            <th scope="col">Registered Date</th>

            <th scope="col">Control</th>
          </tr>
          
          </thead>
          <tbody>    
              <?php 
              foreach($rows as $row){
                  echo '<tr>';
                    echo '<td>'. $row['UserID'] .'</td>';
                    echo '<td>'. $row['Username'] .'</td>';
                    if ($row['GroupID'] == 2){
                        echo '<td>Administrator</td>';
                    }elseif($row['GroupID'] == 3){
                        echo '<td>Salesman</td>';
                    }elseif($row['GroupID'] == 4){
                        echo '<td>Storekeeper</td>';
                    }else {
                        echo '<td>Not Found</td>';
                    }
                    
                    echo '<td>'. $row['Email'] .'</td>';
                    echo '<td>'. $row['FullName'] .'</td>';                                    
                    echo '<td>'. $row['Date'] .'</td>';
                    echo '<td><a href="members.php?do=Edit&userid='.$row['UserID'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> 
                            <a href="members.php?do=Delete&userid='.$row['UserID'].'" class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a> ';
                    echo '</td>';
                  echo '</tr> ';
              }
              ?>                                            
          </tbody>
        </table>
        <a href="members.php?do=Add" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add New User</a>
        <?php 
        }else{
            echo "<div class='container'><br><div class='alert alert-info'>No Records to Display.</div></div>";
            echo '<div class="container"><a href="members.php?do=Add" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add New User</a></div>';
        }
    }else {
        $stmt = $con->prepare("SELECT * FROM users");
        $stmt->execute();
        $rows = $stmt->fetchAll();
        $count = $stmt->rowCount();

        if($stmt->rowCount() > 0 ){
        ?>                        
    <div class="container">       
        
     <h3 class="">Manage Users</h3>
        
        <table class="table table-striped table-hover text-center table-bordered">
          <thead>
          <tr>
            <th scope="col">#ID</th>
            <th scope="col">Username</th>
            <th scope="col">Position</th>
            <th scope="col">Email</th>
            <th scope="col">Full Name</th>
            <th scope="col">Registered Date</th>
            <th scope="col">Control</th>
          </tr>
          
          </thead>
          <tbody>    
              <?php 
              foreach($rows as $row){
                  echo '<tr>';
                    echo '<td>'. $row['UserID'] .'</td>';
                    echo '<td>'. $row['Username'] .'</td>';
                    if ($row['GroupID'] == 2){
                        echo '<td>Administrator</td>';
                    }elseif($row['GroupID'] == 3){
                        echo '<td>Salesman</td>';
                    }elseif($row['GroupID'] == 4){
                        echo '<td>Storekeeper</td>';
                    }else {
                        echo '<td>Super Administrator</td>';
                    }
                    
                    echo '<td>'. $row['Email'] .'</td>';
                    echo '<td>'. $row['FullName'] .'</td>';                                    
                    echo '<td>'. $row['Date'] .'</td>';
                    echo '<td><a href="members.php?do=Edit&userid='.$row['UserID'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> 
                            <a href="members.php?do=Delete&userid='.$row['UserID'].'" class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a> ';
                    echo '</td>';
                  echo '</tr> ';
              }
              ?>                                            
          </tbody>
        </table>
        <a href="members.php?do=Add" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add New User</a>
        <?php 
        }else{
            echo "<div class='container'><br><div class='alert alert-info'>No Records to Display.</div></div>";
            echo '<div class="container"><a href="members.php?do=Add" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add New User</a></div>';
        }
    }
    ?>
        </div>
<?php
    }elseif($do == 'Add'){
        //add members page
        ?>               
            <div class="container">
            <h3 class="">Add New User</h3>
                <form class="row g-3" action="?do=Insert" method="POST">  
                    
                <div class="form-floating col-md-6">                    
                    <input type="text" name="username" class="form-control" id="floatingInput" placeholder="Username" autocomplete="off" >
                    <label for="floatingInput">Username</label>
                    <p>Insert Username</p>
                </div>

                <div class="form-floating col-md-6">
                    
                    <input type="password" name="password" class="form-control" id="floatingInput" placeholder="password" autocomplete="new-passowrd" >
                    <label for="floatingInput">Password</label>
                    <p>Insert Password</p>
                </div>
                <div class="form-floating col-md-6">
                    <input type="email" name="email" class="form-control" id="floatingInput" placeholder="Email" >
                    <label for="floatingInput">Email</label>
                    <p>Insert Email</p>
                </div>
                <div class="form-floating col-md-6">
                    <input type="text" name="full" class="form-control" id="floatingInput" placeholder="fullname" >
                    <label for="floatingInput">Full Name</label>
                    <p>Insert Full Name</p>
                </div>
                <div class="col-md-12">
                <p>Choose User Position</p>
                    <select name="position" class="form-select form-select-sm form-control">
                        <option value="0"></option>
                        <?php
                        if($_SESSION['GroupID'] == 1){
 
                        echo '<option value="1">Super Administrator</option>';
                        }
                        ?>
                        <option value="2">Administrator</option>
                        <option value="3">Storekeeper</option>
                        <option value="4">Salesman</option>
                    </select>
                  
                    
                </div>                

                <div class="col-12">
                    <div class="form-check">
                    <input class="form-check-input is-invalid" type="checkbox" id="invalidCheck3" >
                    <label class="form-check-label" for="invalidCheck3">
                        Upload User Information
                    </label>
                    <div class="invalid-feedback">
                        You must agree before submitting.
                    </div>
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit"class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add User</button>
                </div>
                </form>
     
                 <?php
    }elseif($do == 'Insert'){

        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //get variables from form
            ?> <div class="container"><h3 class="">Insert User</h3><?php

            $user = $_POST['username'];
            $pass = $_POST['password'];
            $email = $_POST['email'];
            $name = $_POST['full'];
            $position = $_POST['position'];

            $hashPass = sha1($_POST['password']);
            
            //validate the form
                $formErrors = array();

                    if(strlen($user) < 4 && strlen($user) != 0){ $formErrors[] ='Username can not be less than 4 characcters.';}                                   
                    if(strlen($user) > 20){ $formErrors[] ='Username can not be more than 20 characcters.';}
                    if(empty($user)){ $formErrors[] ='Username can not be empty.';}
                    if(empty($pass)){ $formErrors[] ='Password can not be empty.';}
                    if(empty($name)){ $formErrors[] ='Full Name can not be empty.';}
                    if(empty($email)){ $formErrors[] ='Email can not be empty.';}

                    foreach ($formErrors as $error){
                        //redirectHome($theMsg, $url = null, $seconds = 20)

                        $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">'.$error.'</div>';
                        redirectHome($theMsg, 'members.php?do=Add', 5);
                        

                    }
                   
                    
            //update database with new info if there is no errors

            if (empty($formErrors)){

                //check if user exist in db
                $check = checkItem("Username","users",$user);

                if($check == 0){

                //insert member into database

                $stmt = $con->prepare("INSERT INTO 
                users(Username, Password, Email, FullName, GroupID, Date) 
                VALUES(:zuser, :zpass, :zmail, :zname, :zposition,now())");
                $stmt->execute(array('zuser' => $user, 'zpass' => $hashPass, 'zmail' => $email, 'zname' => $name, 'zposition' => $position));
                // redirectHome($theMsg, $url = null, $seconds = 20)
                $theMsg =  "<div class='alert alert-success'>User acount added.</div>";
                redirectHome($theMsg,'members.php',1);  
                    
                   
                }else {
                
                    // redirectHome($theMsg, $url = null, $seconds = 20)
                    $theMsg =  "<div class='alert alert-danger'>User Exist, Try again.</div>";
                    redirectHome($theMsg,'members.php?do=Add',1);  


                }
            }
            

        }else{
            ?> <div class="container"><?php
            // redirectHome($theMsg, $url = null, $seconds = 20)
            $theMsg =  "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,'index.php',5);
            
        }
        ?> </div><?php
        
    }elseif($do == 'Edit'){
        
        // if(isset($_GET['userid']) && is_numeric($_GET['userid'])){

        //     echo intval($_GET['userid']);

        // }else{
        //     echo 0;
        // }
        $userid = isset($_GET['userid']) && is_numeric($_GET['userid']) ? intval($_GET['userid']) : 0;

        $stmt = $con->prepare("SELECT * FROM users WHERE UserID = ? LIMIT 1");
        $stmt->execute(array($userid));
        $row = $stmt->fetch();
        $count = $stmt->rowCount();

        if($stmt->rowCount() > 0 ){

            /* */
            ?>               
            <div class="container">
            <h3 class="">Edit User</h3>
                <form class="row g-3" action="?do=Update" method="POST">  
                    <input type="hidden" name="userid" value="<?php echo $userid; ?>">             
                <div class="form-floating col-md-6">                    
                    <input type="text" name="username" value="<?php echo $row['Username'] ?>" class="form-control" id="floatingInput" placeholder="Username" autocomplete="off" >
                    <label for="floatingInput">Username</label>
                    <p>Your Current Username: <?php echo $row['Username'] ?></p>
                </div>
                <div class="form-floating col-md-6">
                    <input type="hidden" name="oldpassword" value="<?php echo $row['Password'] ?>">
                    <input type="password" name="newpassword" class="form-control" id="floatingInput" placeholder="password" autocomplete="new-passowrd" >
                    <label for="floatingInput">Password</label>
                    <p>leave it blank if you don't want to change password</p>
                </div>
                <div class="form-floating col-md-6">
                    <input type="email" name="email" value="<?php echo $row['Email'] ?>" class="form-control" id="floatingInput" placeholder="name@example.com" required="required">
                    <label for="floatingInput">Email</label>
                    <p>Your Current Email: <?php echo $row['Email'] ?></p>
                </div>
                <div class="form-floating col-md-6">
                    <input type="text" value="<?php echo $row['FullName'] ?>" name="full" class="form-control" id="floatingInput" placeholder="fullname" required="required">
                    <label for="floatingInput">Full Name</label>
                    <p>Your Current Full Name: <?php echo $row['FullName'] ?></p>
                </div>
                <div class="col-md-12">
                <p>User Position</p>
                    <select name="position" class="form-select form-select-sm form-control">
                        
                        <option value="1" <?php if( $row['GroupID'] == 1){echo 'selected';} ?>>Super Admin</option>
                        <option value="2" <?php if( $row['GroupID'] == 2){echo 'selected';} ?>>Admin</option>
                        <option value="3" <?php if( $row['GroupID'] == 3){echo 'selected';} ?>>Salesman</option>
                        <option value="4" <?php if( $row['GroupID'] == 4){echo 'selected';} ?>>Storekeeper</option>
                    </select>                                      
                </div>                

                <div class="col-12">
                    <div class="form-check">
                    <input class="form-check-input is-invalid" type="checkbox" id="invalidCheck3" >
                    <label class="form-check-label" for="invalidCheck3">
                        Update User Information
                    </label>
                    <div class="invalid-feedback">
                        You must agree before submitting.
                    </div>
                    </div>
                </div>
                <div class="col-12">
                <button type="submit"class="btn btn-outline-success"><i class="fa fa-edit"></i> Update Changes</button>
                </div>
                </form>
                </div>
                 <?php
            /**/ 

        }else{
            ?> <div class="container"><?php
            //redirectHome($theMsg,'members.php',5);
            $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,null,2);
            ?> </div><?php
        }
        
    }elseif($do == 'Update'){//update page
        ?> <div class="container">  
                <h3 class="">Update User</h3><?php
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //get variables from form
            $id = $_POST['userid'];
            $user = $_POST['username'];
            $email = $_POST['email'];
            $name = $_POST['full'];
            $position = $_POST['position'];


            // password trick
            // $pass = '';
            // if(empty($_POST['newpassword'])){
            //     $pass = $_POST['oldpassword'];

            // }else{
            //     $pass = sha1($_POST['newpassword']);
            // }
            $pass = empty($_POST['newpassword']) ? $_POST['oldpassword'] : sha1($_POST['newpassword']); 
            //validate the form
            $formErrors = array();

                if(strlen($user) < 4 && strlen($user) != 0){ $formErrors[] ='Username can not be less than 4 characcters.';}                                   
                if(strlen($user) > 20){ $formErrors[] ='Username can not be more than 20 characcters.';}
                if(empty($user)){ $formErrors[] ='Username can not be empty.';}
                if(empty($name)){ $formErrors[] ='Full Name can not be empty.';}
                if(empty($email)){ $formErrors[] ='Email can not be empty';}

            foreach ($formErrors as $error){
                $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">'.$error.'</div>';
                redirectHome($theMsg, 'members.php?do=Edit&userid='.$id.'', 5);
            }

            //update database with new info if there is no errors
            $check = countItems("*", "users", "WHERE Username = '$user' AND UserID != $id");
              /*
              1 => exist
              0 => not exist
               

              */
              if($check == 1 ){
                $theMsg =  "<div class='alert alert-danger'>User Exist, Try again.</div>";
                redirectHome($theMsg,'members.php?do=Edit&userid='.$id.'',2);  

            }
            if (empty($formErrors && $check == 0)){

                //echo $id . $user . $email . $name;
                $stmt = $con->prepare("UPDATE users SET Username = ?, Email = ?, FullName = ?, Password = ?, GroupID = ? WHERE UserID = ?");
                $stmt->execute(array($user, $email, $name, $pass, $position, $id));
                //echo success message
                if($stmt->rowCount() > 0){
                   // redirectHome($theMsg, $url = null, $seconds = 20)
                    $theMsg = "<div class='alert alert-success  alert-dismissible fade show' role='alert'>Record Updated.</div>";
                    redirectHome($theMsg,'members.php',2);
        
                    
                }else{
                   
                    $theMsg = "<div class='alert alert-secondary alert-dismissible fade show' role='alert'>Record not Updated.</div>";
                    redirectHome($theMsg,'members.php',2);

                }
            }

        }else{
            $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,null,5);
        }
        ?> </div><?php

    }elseif($do == 'Delete'){
        ?> <div class="container">  
                <h3 class="">Delete User</h3>
        <?php
        $userid = isset($_GET['userid']) && is_numeric($_GET['userid']) ? intval($_GET['userid']) : 0;


        $check = checkItem('userid', 'users',$userid );
     

        if($check == 1 ){
            
            $stmt = $con->prepare("DELETE FROM users WHERE UserID = :zuser");

            $stmt->bindParam(":zuser", $userid);

            $stmt->execute();

             //redirectHome($theMsg, $url = null, $seconds = 20)

            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Record Deleted.</div>";

            redirectHome($theMsg, 'members.php?do=Manage', 5);

        }else {
            // redirectHome($theMsg, $url = null, $seconds = 20)

            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Invalid ID.</div>";
            redirectHome($theMsg, null, 5);
        ?> </div><?php
        }
        
    }

    

    include $tpl.'footer.php';

}else{
    // echo 'You Are Not Authorized To Brows This Page';

    header('Location: index.php');

    exist();
}