        
        </div>
        <div class="navbar fixed-bottom">
        <footer class="footer mt-auto py-3 bg-light ">
            <div class="container">
                <span class="text-muted">&copy; Excellence Systems 2010–2021</span>
            </div>
        </footer>
        
        <script src="<?php echo $js; ?>jquery-3.6.0.min.js"></script>
        <script src="<?php echo $js; ?>bootstrap.min.js"></script>
        <script src="<?php echo $js; ?>backend.js"></script>        
    </body>
</html>

