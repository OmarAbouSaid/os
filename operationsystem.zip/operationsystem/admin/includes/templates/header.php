<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8"/>
        <title><?php getTitle()?></title>
        <link rel="stylesheet" href="<?php echo $css;?>bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $css;?>backend.css">
        <link rel="stylesheet" href="<?php echo $css;?>all.min.css">

    </head>
    <body>
    <div class="header">
        <!-- This is Header -->