<?php

function lang($phrase){
    static $lang = array(
        'DASHBOARD'=>'Dashboard',
        'CATEGORIES'=>'Categories',
        'SETTINGS'=>'Settings',
        'LOGOUT'=>'Logout',
        'ITEMS'=>'Items',
        'MEMBERS'=>'Members',
        'INVOICE'=>'Invoice',
        'STOREHOUSE'=>'Storehouse',
        'LOGS'=>'Logs',
        'SEARCH'=>'Search',
        'EDIT_PROFILE'=>'Edit Profile'
    );
    return $lang[$phrase];
}