<?php
if(isset($_POST["getNewOrderItem"])){
    $stmt = $con->prepare("SELECT * FROM items");
    $stmt->execute();
    $items = $stmt->fetchAll();
    ?>
            <tr>
        <tr>
        <td><b id="number">1</b></td>
        <td>
            <select name="pid[]" class="form-control form-control-sm" required>
                <?php 
                foreach($items as $item){
                echo '<option value="'.$item['Item_ID'].'">'.$item['Name'].'</option>';
                }
                ?>
            </select>
        </td>
        <td><input name="tqty[]" type="text" class="form-control form-control-sm" readonly></td>

        <td><input name="qty[]" type="text" class="form-control form-control-sm" required></td>
        <td><input name="price[]" type="text" class="form-control form-control-sm" readonly></td>
        <td> SYP</td>
        </tr> 

    <?php

}