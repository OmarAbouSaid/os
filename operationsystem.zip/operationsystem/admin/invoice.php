<?php

ob_start();
session_start();
$pageTitle = '';

if(isset($_SESSION['Username'])){
    include 'init.php';
    $do = isset($_GET['do']) ? $_GET['do']: 'Manage';
    if($do == 'Manage'){

        ?>
                    <div class="container">
                        <h3 class="">My Invoices</h3>
                        <a href="order.php" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Create Invoice</a>
                        <br>    
                    </div>

        <?php
        echo '<div class="container"><a href="invoice.php?do=customer" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Create Invoice</a></div>';
    }elseif($do == 'customer'){
        $stmt = $con->prepare("SELECT * FROM customer");
        $stmt->execute();
        $customers = $stmt->fetchAll();
        if($stmt->rowCount() > 0 ){
        ?>                        
        <div class="container">       
        <h3 class="">List of Customers</h3>
        <table class="table table-striped table-hover text-center table-bordered">
        <thead>
        <tr>
        <th scope="col">Name</th>
        <th scope="col">Contact Number</th>
        <th scope="col"></th>
        </tr>
        <!-- Scrollable modal -->
        </thead>
        <tbody>    
        <?php 
        foreach($customers as $customer){
        echo '<tr>';
        echo '<td>'. $customer['customer_name'] .'</td>';
        echo '<td>'. $customer['contact_number'] .'</td>';
        echo '<td><a href="invoice.php?do=createinvoice&customerid='.$customer['customer_ID'].'" class="btn btn-outline-info btn-sm"><i class="fa fa-check"></i> Select</a>';         echo '</td>';
        echo '</tr> ';
        }
        ?>                                            
        </tbody>
        </table>
        </div>
        <?php }else 
        echo "</br><div class='container'> <div class='alert alert-info'>No Records to Display.</div></div>";
        echo '<div class="container"><a href="invoice.php?do=addcustomer" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add New Customer</a></div>';
        ?> 

        <?php
    }elseif($do == 'addcustomer'){
        ?>               
        <div class="container">
        <h3 class="">Add New Customer</h3>
            <form class="row g-3" action="?do=insertcustomer" method="POST">  
            
            <div class="form-floating col-md-12">
                <input type="text" name="name" class="form-control" id="floatingInput" placeholder="Item Name" autocomplete="off">
                <label for="floatingInput">Customer Name</label>
                <p><small>Insert Customer Name</small></p>
            </div>
            <div class="form-floating col-md-12">
                <input type="number" name="number" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                <label for="floatingInput">Customer Contact Number</label>
                <p><small>Customer Contact Number</small></p>
            </div>                
            <div class="col-12">
                <button type="submit"class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add Storehouse</button>
            </div>
            </form>
             <?php    
        }elseif($do == 'insertcustomer'){
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                //get variables from form
                ?> <div class="container"><h3 class="">Create Customer</h3><?php
                $name = $_POST['name'];
                $number = $_POST['number'];
                    $formErrors = array();
                        if(strlen($name) < 4 && strlen($name) != 0){ $formErrors[] ='Customer Name can not be less than 4 characcters.';}                                   
                        if(strlen($name) > 20){ $formErrors[] ='Customer Name can not be more than 20 characcters.';}
                        if(empty($name)){ $formErrors[] ='Customer Name can not be empty.';}
                        if(empty($number)){ $formErrors[] ='Customer Contact Number can not be empty.';}
    
                        foreach ($formErrors as $error){
                            //redirectHome($theMsg, $url = null, $seconds = 20)
                            $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">'.$error.'</div>';
                            redirectHome($theMsg, 'invoice.php?do=addcustomer', 2);                        
                        }             
                //update database with new info if there is no errors
                if (empty($formErrors)){
                  $statement = $con->prepare("SELECT customer_name, contact_number FROM customer WHERE customer_name = ? AND contact_number = ?");
                  $statement->execute(array($name, $number));
                  $count = $statement->rowCount();
                  if($count == 0){ 

                    
                     $stmt = $con->prepare("INSERT INTO customer(customer_name, contact_number) 
                     VALUES(:zname, :znumber)");
                     $stmt->execute(array('zname' => $name, 'znumber'=>$number));
                     $theMsg =  "<div class='alert alert-success'>Customer added.</div>";
                     redirectHome($theMsg,'invoice.php?do=customer',3);  
                     
                  }else {
                    $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">Customer Exist</div>';
                    redirectHome($theMsg, 'invoice.php?do=addcustomer', 2);                        

                  }
                }
            }else{
                ?> <div class="container"><?php
                // redirectHome($theMsg, $url = null, $seconds = 20)
                $theMsg =  "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
                redirectHome($theMsg,'index.php',2);
            }
            ?> </div><?php
    
    
    }elseif($do == 'createinvoice'){
        $stmt = $con->prepare("INSERT INTO invoice(customer_id, invoice_date) 
        VALUES(:zcustomerid, now())");
        $stmt->execute(array('zcustomerid' => $_GET["customerid"]));


?> 
        <div class="container">
            <h3 class="">Add New Invoice</h3>
                <form class="row g-3" action="" method="POST">  
                <input type="hidden" name="customerid" value='<?php echo $_GET["customerid"]?>'>

                
                <div class="form-floating col-md-3">
                <?php 
                            $stmt = $con->prepare("SELECT invoice_ID FROM invoice WHERE customer_id = ? ORDER BY invoice_ID DESC LIMIT 1 ");
                            $stmt->execute(array($_GET["customerid"]));
                            $invoices = $stmt->fetchAll();
                            foreach($invoices as $invoice){
                                
                                echo '<h6>Bill ID#'.$invoice['invoice_ID'].'</h6>';
                            }
                                ?>
                </div>
                <div class="form-floating col-md-3">
                    <h6>Date: <?php echo date('d/m/y');?></h6>
                </div>

                <div class="form-floating col-md-3">
                    <?php 
                            $stmt = $con->prepare("SELECT customer_name FROM customer WHERE customer_ID = ?");
                            $stmt->execute(array($_GET["customerid"]));
                            $customers = $stmt->fetchAll();
                            foreach($customers as $customer){

                                echo '<h6>Customer Name: '.$customer['customer_name'].'</h6>';
                            }
                                ?>
                </div>
                <div class="form-floating col-md-3">
                    <?php 
                            $stmt = $con->prepare("SELECT contact_number FROM customer WHERE customer_ID = ?");
                            $stmt->execute(array($_GET["customerid"]));
                            $customers = $stmt->fetchAll();
                            foreach($customers as $customer){

                                echo '<h6>Customer Contact Number: '.$customer['contact_number'].'</h6>';
                            }
                                ?>
                </div>
                <hr>

                <div class="form-floating col-md-4">
                    <textarea type="text" name="address" class="form-control" id="floatingInput" placeholder="description" autocomplete="new-passowrd" ></textarea>
                    <label for="floatingInput">Order Addressed to</label>
                    <p><small>Insert customer Address</small></p>
                </div>
                

                <div class="col-12">
                    <button type="submit"class="btn btn-outline-primary"><i class="fa fa-plus"></i> Create Bill</button>
                </div>
              
                </form>

</div>
<?php
    }
include $tpl . 'footer.php';
 
}else {
        header('location: index.php');
        exit();
}


ob_end_flush();