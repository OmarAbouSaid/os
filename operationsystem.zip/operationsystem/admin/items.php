<?php

ob_start();
session_start();
$pageTitle = 'Items';

if(isset($_SESSION['Username'])){
    include 'init.php';
    $do = isset($_GET['do']) ? $_GET['do']: 'Manage';
    if($do == 'Manage'){
        $stmt = $con->prepare("SELECT 
                                    items.*, subsubcategory.Name 
                                    AS category_name, users.Username, store.store_name 
                                FROM items 
                                    INNER JOIN subsubcategory 
                                    ON subsubcategory.SSID = items.Cat_ID 
                                    INNER JOIN users 
                                    ON users.UserID = items.Member_ID
                                    INNER JOIN store 
                                    ON store.store_id = items.Store_ID");
        $stmt->execute();
        $items = $stmt->fetchAll();
        if($stmt->rowCount() > 0 ){
        ?>                        
    <div class="container">       
     <h3 class="">Manage Items</h3>
        <table class="table table-striped table-hover text-center table-bordered">
          <thead>
          <tr>
            <th scope="col">#ID</th>
            <th scope="col">Image</th>
            <th scope="col">Name</th>
            <th scope="col">Description</th>
            <th scope="col">Height</th>
            <th scope="col">Width</th>
            <th scope="col">Color</th>
            <th scope="col">Price</th>
            <th scope="col">Weight</th>
            <th scope="col">Visibility</th>            
            <th scope="col">Quantity</th>
            <th scope="col">Category</th>
            <th scope="col">Store House</th>
            <th scope="col">Control</th>
          </tr>
          <!-- Scrollable modal -->
          </thead>
          <tbody>    
              <?php 
              $i =1;
              foreach($items as $item){
                  echo '<tr>';
                    echo '<td>'. $item['Item_ID'] .'</td>';
                    echo '<td>'. $item['Image'] .'</td>';
                    echo '<td>'. $item['Name'] .'</td>';
                    // desc start
                    if (empty($item['Description'])){
                        echo '<td><em>No Description Added</em></td>';
                    }elseif (strlen($item['Description']) <= 12 && strlen($item['Description']) != 0) {
                        echo '<td>'. $item['Description'] .'</td>';
                    }else{
                    echo '<td><div class="d-inline-block text-truncate" style="max-width: 100px;">'. $item['Description'] .'</div>
                    <!-- Button trigger modal -->
                    <a  class="link-primary" data-bs-toggle="modal" data-bs-target="#exampleModal'.$i.'">
                         Read More..
                    </a>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal'.$i.'" tabindex="-'.$i.'" aria-labelledby="exampleModal'.$i.'Label" aria-hidden="true">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                          <h6>'. $item['Name'] .' Description</h6>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                          '. $item['Description'] .'
                          </div>    
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>                      
                        </div>
                      </div>
                    </div>                                                                
                    </td>';}
                    //desc end
                    echo '<td>'. $item['height'] .'</td>';                                    
                    echo '<td>'. $item['width'] .'</td>'; 
                    echo '<td>'. $item['color'] .'</td>'; 
                    echo '<td>'. $item['price'] .'</td>'; 
                    echo '<td>'. $item['weight'] .'</td>'; 
                        if($item['visibility'] == 1){
                            echo '<td>Visible</td>'; 
                        }elseif($item['visibility'] == 2) {
                            echo '<td>Inisible</td>'; 
                        }
                        else {
                            echo '<td>Not Defined</td>'; 
                        }

                    echo '<td>'. $item['quantity'] .'</td>'; 
                    echo '<td>'. $item['category_name'] .'</td>';
                    echo '<td>'. $item['store_name'] .'</td>';
                    echo '<td><a href="items.php?do=Edit&itemid='.$item['Item_ID'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> 
                            <a href="items.php?do=Delete&itemid='.$item['Item_ID'].'"class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a> ';
                    echo '</td>';
                  echo '</tr> ';
                  $i = $i + 1;
              }
              ?>                                            
          </tbody>
        </table>
        </div>
        <?php }else 
    echo "</br><div class='container'> <div class='alert alert-info'>No Records to Display.</div></div>";
    echo '<div class="container"><a href="items.php?do=Add" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add New Item</a></div>';
    ?> 

<?php
    }elseif($do == 'Add'){
        //add members page
        ?>               
            <div class="container">
            <h3 class="">Add New Item</h3>
                <form class="row g-3" action="?do=Insert" method="POST">  
                
                <div class="form-floating col-md-4">
                    <input type="text" name="name" class="form-control" id="floatingInput" placeholder="Item Name" autocomplete="off">
                    <label for="floatingInput">Item Name</label>
                    <p><small>Insert Item Name</small></p>
                </div>
                <div class="form-floating col-md-12">
                    <textarea type="text" name="description" class="form-control" id="floatingInput" placeholder="description" autocomplete="new-passowrd" ></textarea>
                    <label for="floatingInput">Item Description</label>
                    <p><small>Insert Item Description</small></p>
                </div>
                <div class="form-floating col-md-6">
                    <input type="number" name="price" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Item Price</label>
                    <p><small>Insert Item Price</small></p>
                </div>                
                <div class="form-floating col-md-6">
                    <input type="number" name="height" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Item Height</label>
                    <p><small>Insert Item Height</small></p>
                </div>                
                <div class="form-floating col-md-6">
                    <input type="number" name="width" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Item Width</label>
                    <p><small>Insert Item Width</small></p>
                </div>                
                <div class="form-floating col-md-6">
                    <input type="number" name="weight" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Item Weight</label>
                    <p><small>Insert Item Weight</small></p>
                </div>                
                <div class="form-floating col-md-6">
                    <input type="color" name="color" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Item Color</label>
                    <p><small>Insert Item Color</small></p>
                </div>                
                
                <div class="form-floating col-md-6">
                    <input type="number" name="quantity" class="form-control" id="floatingInput" placeholder="Country Made" autocomplete="off">
                    <label for="floatingInput">Item Quantity</label>
                    <p><small>Insert Item Quantity</small></p>
                </div>                
                <div class="col-md-12">
                <p>Choose Item Status</p>
                    <select name="visibility" class="form-select form-select-sm form-control">
                        <option value="0"></option>
                        <option value="1">Visible</option>
                        <option value="2">Invisible</option>
                    </select>
                </div>                
                <div class="col-md-12">
                <p>Member</p>
                    <select name="member" class="form-select form-select-sm form-control">
                        <option value="0"></option>
                        <?php 
                        $stmt = $con->prepare("SELECT * FROM users");
                        $stmt->execute();
                        $users = $stmt->fetchAll();
                        foreach ($users as $user){
                            echo "<option value='".$user['UserID']."'>".$user['Username']."</option>";
                        }
                        ?>
                    </select>
                </div>                
                <div class="col-md-12">
                <p>Category</p>
                    <select name="category" class="form-select form-select-sm form-control">
                        <option value="0"></option>
                        <?php 
                        $stmt1 = $con->prepare("SELECT subsubcategory.SSID, subsubcategory.Name as ssname, subcategory.SubName as sname, categories.Name as name FROM subsubcategory INNER JOIN subcategory ON subsubcategory.SubSubID = subcategory.SID INNER JOIN categories ON subcategory.SubID = categories.ID;");
                        $stmt1->execute();
                        $cats = $stmt1->fetchAll();
                        foreach ($cats as $cat){
                            echo "<option value='".$cat['SSID']."'>".$cat['name']."->".$cat['sname']."->".$cat['ssname']."</option>";
                        }
                        ?>
                    </select>
                </div>    
                <div class="col-md-12">
                <p>Storehouse</p>
                    <select name="store" class="form-select form-select-sm form-control">
                        <option value="0"></option>
                        <?php 
                        $stmt1 = $con->prepare("SELECT * FROM store ;");
                        $stmt1->execute();
                        $stores = $stmt1->fetchAll();
                        foreach ($stores as $store){
                            echo "<option value='".$store['store_id']."'>".$store['store_name']."</option>";
                        }
                        ?>
                    </select>
                </div>    
                <div class="col-12">
                    <button type="submit"class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add Item</button>
                </div>
                </form>
                 <?php    
    }elseif($do == 'Insert'){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //get variables from form
            ?> <div class="container"><h3 class="">Insert Item</h3><?php
            $name = $_POST['name'];
            $desc = $_POST['description'];
            $height = $_POST['height'];
            $width = $_POST['width'];
            $color = $_POST['color'];
            $price = $_POST['price'];
            $weight = $_POST['weight'];
            $visibility = $_POST['visibility'];
            $quantity = $_POST['quantity'];
            $member = $_POST['member'];
            $cat = $_POST['category']; 
            $store = $_POST['store']; 
            //validate the form
                $formErrors = array();
                    if(strlen($name) < 4 && strlen($name) != 0){ $formErrors[] ='Item Name name can not be less than 4 characcters.';}                                   
                    if(strlen($name) > 20){ $formErrors[] ='Item Name can not be more than 20 characcters.';}
                    if(empty($name)){ $formErrors[] ='Item Name can not be empty.';}
                    if(empty($height)){ $formErrors[] ='Item Height can not be empty.';}
                    if(empty($width)){ $formErrors[] ='Item Width can not be empty.';}
                    if(empty($color)){ $formErrors[] ='Item Color can not be empty.';}
                    if(empty($weight)){ $formErrors[] ='Item Weight can not be empty.';}
                    if(empty($quantity)){ $formErrors[] ='Item Quantity can not be empty.';}
                    if(empty($desc)){ $formErrors[] ='Description can not be empty.';}
                    if(empty($price)){ $formErrors[] ='Price Item can not be empty.';}
                    if(empty($visibility) || $visibility === 0){ $formErrors[] ='Item Visibility must be choosen.';}
                    if(empty($member) || $member === 0){ $formErrors[] ='Member must be choosen.';}
                    if(empty($cat) || $cat === 0){ $formErrors[] ='Category must be choosen.';}
                    if(empty($store) || $store === 0){ $formErrors[] ='Storehouse must be choosen.';}
                    foreach ($formErrors as $error){
                        //redirectHome($theMsg, $url = null, $seconds = 20)
                        $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">'.$error.'</div>';
                        redirectHome($theMsg, 'items.php?do=Add', 2);                        
                    }             
            //update database with new info if there is no errors
            if (empty($formErrors)){ 
               // echo 'insert member into database';
                 $stmt = $con->prepare("INSERT INTO items(Name, Description, height, width, color, weight, Price, quantity, visibility, Cat_ID, Store_ID, Member_ID) 
                 VALUES(:zname, :zdesc, :zheight, :zwidth, :zcolor, :zweight, :zprice,:zquantity,:zvisibility, :zcatid,:zstoreid, :zmemberid)");
                 $stmt->execute(array('zname' => $name, 'zdesc' => $desc, 'zheight'=>$height,'zwidth'=>$width,'zcolor'=>$color,'zweight'=>$weight,'zprice'=>$price, 'zquantity'=>$quantity, 'zvisibility'=>$visibility, 'zcatid'=>$cat, 'zstoreid'=>$store,'zmemberid'=>$member ));
                 $theMsg =  "<div class='alert alert-success'>Item added.</div>";
                 redirectHome($theMsg,'items.php',3);  
            }
        }else{
            ?> <div class="container"><?php
            // redirectHome($theMsg, $url = null, $seconds = 20)
            $theMsg =  "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,'index.php',2);
        }
        ?> </div><?php
    }elseif($do == 'Edit') {
        $itemid = isset($_GET['itemid']) && is_numeric($_GET['itemid']) ? intval($_GET['itemid']) : 0;
        $stmt = $con->prepare("SELECT * FROM items WHERE Item_ID = ?");
        $stmt->execute(array($itemid));
        $item = $stmt->fetch();
        $count = $stmt->rowCount();
        if($stmt->rowCount() > 0 ){
            /* */
            ?>               
            <div class="container">
            <h3 class="">Edit Item</h3>
                <form class="row g-3" action="?do=Update" method="POST">  
                <input type="hidden" name="itemid" value="<?php echo $itemid; ?>">  
                <div class="form-floating col-md-4">
                    <input type="text" name="name" value="<?php echo $item['Name'] ?>" class="form-control" id="floatingInput" placeholder="Item Name" autocomplete="off">
                    <label for="floatingInput">Item Name</label>
                    <p><small>Update Item Name</small></p>
                </div>
                <div class="form-floating col-md-12">
                    <textarea type="text" name="description" class="form-control" id="floatingInput" placeholder="description" autocomplete="new-passowrd" ><?php echo $item['Description'] ?></textarea>
                    <label for="floatingInput">Item Description</label>
                    <p><small>Update Item Description</small></p>
                </div>
                <div class="form-floating col-md-6">
                    <input type="number" name="price" value="<?php echo $item['price'] ?>" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Item Price</label>
                    <p><small>Update Item Price</small></p>
                </div>                
                <div class="form-floating col-md-6">
                    <input type="number" name="height" value="<?php echo $item['height'] ?>" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Item Height</label>
                    <p><small>Update Item Height</small></p>
                </div>                
                <div class="form-floating col-md-6">
                    <input type="number" name="width" value="<?php echo $item['width'] ?>" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Item Width</label>
                    <p><small>Update Item Width</small></p>
                </div>                
                <div class="form-floating col-md-6">
                    <input type="number" name="weight" value="<?php echo $item['weight'] ?>" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Item Weight</label>
                    <p><small>Update Item Weight</small></p>
                </div>                
                <div class="form-floating col-md-6">
                    <input type="color" name="color" value="<?php echo $item['color'] ?>" class="form-control" id="floatingInput" placeholder="Item Price" autocomplete="off">
                    <label for="floatingInput">Item Color</label>
                    <p><small>Update Item Color</small></p>
                </div>                
                <div class="form-floating col-md-6">
                    <input type="number" name="quantity" value="<?php echo $item['quantity'] ?>" class="form-control" id="floatingInput" placeholder="Country Made" autocomplete="off">
                    <label for="floatingInput">Item Quantity</label>
                    <p><small>Update Item Quantity</small></p>
                </div>                
                <div class="col-md-6">
                <p>Update Item Visibility</p>
                    <select name="visibility" class="form-select form-select-sm form-control">
                        <option value="1"<?php if($item['visibility'] == 1) { echo "selected"; }   ?>>Visible</option>
                        <option value="2"<?php if($item['visibility'] == 2) { echo "selected"; }   ?>>Inisible</option>
                    </select>
                </div>                
                <div class="col-md-6">
                <p>Update Item Member</p>
                    <select name="member" class="form-select form-select-sm form-control">                     
                       <?php 
                        $stmt = $con->prepare("SELECT * FROM users");
                        $stmt->execute();
                        $users = $stmt->fetchAll();
                        foreach ($users as $user){
                            ?><option value="<?php echo $user['UserID'];?>"<?php if($item['Member_ID'] == $user['UserID']){echo 'selected';} ?>><?php echo $user['Username']; ?></option><?php                            
                        }
                        ?>
                    </select>                                        
                </div>                
                <div class="col-md-6">
                <p>Update Item Category</p>
                    <select name="category" class="form-select form-select-sm form-control">                     
                       <?php 
                        $stmt = $con->prepare("SELECT subsubcategory.*, subcategory.SubName as sname, categories.Name as catname FROM subsubcategory INNER JOIN subcategory ON subsubcategory.SubSubID = subcategory.SID INNER JOIN categories ON subcategory.SubID = categories.ID;");
                        $stmt->execute();
                        $cats = $stmt->fetchAll();
                        foreach ($cats as $cat){
                            ?><option value="<?php echo $cat['SSID'];?>"<?php if($item['Cat_ID'] == $cat['SSID']){echo 'selected';} ?>><?php echo $cat['catname']." -> ".$cat['sname']." -> ".$cat['Name']?></option><?php                            
                        }
                        ?>
                    </select>                                        
                </div>                

                <div class="col-md-6">
                <p>Update Item Storehouse</p>
                    <select name="store" class="form-select form-select-sm form-control">                     
                       <?php 
                        $stmt = $con->prepare("SELECT * FROM store ;");
                        $stmt->execute();
                        $stores = $stmt->fetchAll();
                        foreach ($stores as $store){
                            ?><option value="<?php echo $store['store_id'];?>"<?php if($item['Store_ID'] == $store['store_id']){echo 'selected';} ?>><?php echo $store['store_name']?></option><?php                            
                        }
                        ?>
                    </select>                                        
                </div>                
                <div class="col-12">
                    <button type="submit"class="btn btn-outline-success"><i class="fa fa-edit"></i> Update Changes</button>
                </div>
                </form>
        </div>
        <?php 
        }else{
            ?> <div class="container"><?php
            //redirectHome($theMsg,'members.php',5);
            $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,null,2);
            ?> </div><?php
        }
    }elseif($do == 'Update') {
                    ?> <div class="container">  
                    <h3 class="">Update Item</h3><?php
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                //get variables from form
                $itemid = $_POST['itemid'];
                $desc = $_POST['description'];
                $price = $_POST['price'];
                $name = $_POST['name'];
                $height = $_POST['height'];
                $width = $_POST['width'];
                $color = $_POST['color'];
                $weight = $_POST['weight'];
                $visibility = $_POST['visibility'];
                $quantity = $_POST['quantity'];
                $member = $_POST['member'];
                $cat = $_POST['category']; 
                $store = $_POST['store']; 

                $formErrors = array();
                if(strlen($name) < 4 && strlen($name) != 0){ $formErrors[] ='Item Name name can not be less than 4 characcters.';}                                   
                if(strlen($name) > 20){ $formErrors[] ='Item Name can not be more than 20 characcters.';}
                if(empty($name)){ $formErrors[] ='Item Name can not be empty.';}
                if(empty($height)){ $formErrors[] ='Item Height can not be empty.';}
                if(empty($width)){ $formErrors[] ='Item Width can not be empty.';}
                if(empty($color)){ $formErrors[] ='Item Color can not be empty.';}
                if(empty($weight)){ $formErrors[] ='Item Weight can not be empty.';}
                if(empty($quantity)){ $formErrors[] ='Item Quantity can not be empty.';}
                if(empty($desc)){ $formErrors[] ='Description can not be empty.';}
                if(empty($price)){ $formErrors[] ='Price Item can not be empty.';}
                if(empty($visibility) || $visibility === 0){ $formErrors[] ='Item Visibility must be choosen.';}
                if(empty($member) || $member === 0){ $formErrors[] ='Member must be choosen.';}
                if(empty($store) || $store === 0){ $formErrors[] ='Storehouse must be choosen.';}
                if(empty($cat) || $cat === 0){ $formErrors[] ='Category must be choosen.';}

                    foreach ($formErrors as $error){
                        //redirectHome($theMsg, $url = null, $seconds = 20)
                        $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">'.$error.'</div>';
                        redirectHome($theMsg, 'items.php?do=Edit&itemid='.$itemid.'', 2);
                    }
                if (empty($formErrors)){
                    $stmt = $con->prepare("UPDATE items 
                    SET 
                    Name = ?,Description = ?,Price = ?, Cat_ID = ?, Member_ID = ?, height = ?, width = ?, color = ?, weight = ?, visibility = ?, quantity = ? , Store_ID = ?
                    WHERE Item_ID = ?");
                    $stmt->execute(array($name, $desc, $price, $cat, $member, $height, $width, $color, $weight, $visibility, $quantity, $store, $itemid));
                    if($stmt->rowCount() > 0){
                    // redirectHome($theMsg, $url = null, $seconds = 20)
                        $theMsg = "<div class='alert alert-success  alert-dismissible fade show' role='alert'>Record Updated.</div>";
                        redirectHome($theMsg,'items.php',2);
                    }else{
                        $theMsg = "<div class='alert alert-secondary alert-dismissible fade show' role='alert'>Record not Updated.</div>";
                        redirectHome($theMsg,'items.php',2);
                    }
                }
            }else{
                $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
                redirectHome($theMsg,null,5);
            }
            ?> </div><?php
    }elseif($do == 'Delete') {
        ?> <div class="container">  
                <h3 class="">Delete Item</h3>
        <?php
        $itemid = isset($_GET['itemid']) && is_numeric($_GET['itemid']) ? intval($_GET['itemid']) : 0;
        $check = checkItem('Item_ID', 'items',$itemid );
        if($check == 1 ){
            $stmt = $con->prepare("DELETE FROM items WHERE Item_ID = :zitem");
            $stmt->bindParam(":zitem", $itemid);
            $stmt->execute();
            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Record Deleted.</div>";
            redirectHome($theMsg, 'items.php?do=Manage', 2);
        }else {
            // redirectHome($theMsg, $url = null, $seconds = 20)
            $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Invalid ID.</div>";
            redirectHome($theMsg, null, 2);
        ?> </div><?php
        }
    }
    include $tpl . 'footer.php';
    
}else {
        header('location: index.php');
        exit();
}
ob_end_flush();