<?php

ob_start();
session_start();
$pageTitle = 'Settings';

if(isset($_SESSION['Username'])){
    include 'init.php';
    $do = isset($_GET['do']) ? $_GET['do']: 'Manage';

    if($do == 'Manage'){


    ?>
            <div class="container">
            <h3 class="">System Settings</h3>
            <div class="card" style="width: 18rem;">
            <div class="card-header">
                Item Colors
            </div>
            
            <ul class="list-group list-group-flush">
            <li class="list-group-item color text-center">
            <table class="table table-hover ">
          <thead>
          <!-- Scrollable modal -->
          </thead>
          <tbody>    
              <?php 
              //padding: 0px 0px;
              $num ==1; 
                      $stmt = $con->prepare("SELECT item_color, itemsdetails_ID FROM itemsdetails where itemsdetails_ID !=1");
                      $stmt->execute();
                      $itemsdetails = $stmt->fetchAll();
              
              foreach($itemsdetails as $itemsdetail){
                  echo '<tr>';
                    echo '<td>'. $itemsdetail['item_color'] .'</td>';
                    if($itemsdetail['itemsdetails_ID']!= 1){
                    echo '<td><a href="settings.php?do=Editcolor&itemsdetailsid='.$itemsdetail['itemsdetails_ID'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> 
                            <a href="settings.php?do=Deletecolor&itemsdetailsid='.$itemsdetail['itemsdetails_ID'].'"class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a> ';
                    echo '</td>';
                    }else{
                        echo '<td></td>';}
                  echo '</tr> ';
                  
                  
              }

              ?>                                            
          </tbody>
        </table>
              <?php 
              
                    echo '<a href="settings.php?do=Addcolor" class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add New Color</a>';

              ?>
            </li>
        </ul>
            </div>
            </div>
    <?php

    

    }elseif($do == 'Addcolor'){
            //add members page
            ?>               
            <div class="container">
            <h3 class="">Add New Color</h3>
                <form class="row g-3" action="?do=Insertcolor" method="POST">  
                
                <div class="form-floating col-md-3">
                    <input type="text" name="name" class="form-control" id="floatingInput" placeholder="Item Name" autocomplete="off">
                    <label for="floatingInput">Item Color</label>
                    <p><small>Insert Item Color</small></p>
                </div>
                <div class="col-12">
                    <button type="submit"class="btn btn-outline-primary"><i class="fa fa-plus"></i> Add Storehouse</button>
                </div>
                </form>
                 <?php    

    }elseif($do == 'Insertcolor'){
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            //get variables from form
            ?> <div class="container"><h3 class="">Insert Item Color</h3><?php
            $name = $_POST['name'];
                $formErrors = array();
                    if(strlen($name) < 3 && strlen($name) != 0){ $formErrors[] ='Item Color can not be less than 3 characcters.';}                                   
                    if(strlen($name) > 50){ $formErrors[] ='Item Color can not be more than 20 characcters.';}
                    if(empty($name)){ $formErrors[] ='Item Color can not be empty.';}

                    foreach ($formErrors as $error){
                        //redirectHome($theMsg, $url = null, $seconds = 20)
                        $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">'.$error.'</div>';
                        redirectHome($theMsg, 'settings.php?do=Addcolor', 2);                        
                    }             
            //update database with new info if there is no errors
            if (empty($formErrors)){
               // echo 'insert member into database';
                 $stmt = $con->prepare("INSERT INTO itemsdetails(item_color) 
                 VALUES(:zname)");
                 $stmt->execute(array('zname' => $name));
                 $theMsg =  "<div class='alert alert-success'>Item Color added.</div>";
                 redirectHome($theMsg,'settings.php',3);  
            }
        }else{
            ?> <div class="container"><?php
            // redirectHome($theMsg, $url = null, $seconds = 20)
            $theMsg =  "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,'index.php',2);
        }
        ?> </div><?php

        
    }elseif($do == 'Editcolor') {
        $itemsdetailsid = isset($_GET['itemsdetailsid']) && is_numeric($_GET['itemsdetailsid']) ? intval($_GET['itemsdetailsid']) : 0;
        $stmt = $con->prepare("SELECT * FROM itemsdetails WHERE itemsdetails_ID = ?");
        $stmt->execute(array($itemsdetailsid));
        $itemsdetail = $stmt->fetch();
        $count = $stmt->rowCount();
        if($stmt->rowCount() > 0 ){
            /* */
            ?>               
            <div class="container">
            <h3 class="">Edit Item Color</h3>
                <form class="row g-3" action="?do=Updatecolor" method="POST">  
                <input type="hidden" name="itemsdetailsid" value="<?php echo $itemsdetailsid; ?>">  
                <div class="form-floating col-md-4">
                    <input type="text" name="name" value="<?php echo $itemsdetail['item_color'] ?>" class="form-control" id="floatingInput" placeholder="Item Color" autocomplete="off">
                    <label for="floatingInput">Item Color</label>
                    <p><small>Update Item Color</small></p>
                </div>
                <div class="col-12">
                    <button type="submit"class="btn btn-outline-success"><i class="fa fa-edit"></i> Update Changes</button>
                </div>
                </form>
        </div>
        <?php 
        }else{
            ?> <div class="container"><?php
            //redirectHome($theMsg,'members.php',5);
            $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
            redirectHome($theMsg,null,2);
            ?> </div><?php
        }

        
    }elseif($do == 'Updatecolor') {
        ?> <div class="container">  
        <h3 class="">Update Item Color</h3><?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    //get variables from form
    $itemsdetailsid = $_POST['itemsdetailsid'];
    $name = $_POST['name'];
    
    $formErrors = array();
    if(strlen($name) < 3 && strlen($name) != 0){ $formErrors[] ='Item Color can not be less than 3 characcters.';}                                   
    if(strlen($name) > 50){ $formErrors[] ='Item Color can not be more than 20 characcters.';}
    if(empty($name)){ $formErrors[] ='Item Color can not be empty.';}

        foreach ($formErrors as $error){
            //redirectHome($theMsg, $url = null, $seconds = 20)
            $theMsg = '<div class="alert alert-danger alert-dismissible fade show" role="alert">'.$error.'</div>';
            redirectHome($theMsg, 'settings.php?do=Editcolor&storeid='.$itemsdetailsid.'', 2);
        }
    if (empty($formErrors)){
        $stmt = $con->prepare("UPDATE itemsdetails 
        SET 
        item_color = ?
        WHERE itemsdetails_ID = ?");
        $stmt->execute(array($name, $itemsdetailsid));
        if($stmt->rowCount() > 0){
        // redirectHome($theMsg, $url = null, $seconds = 20)
            $theMsg = "<div class='alert alert-success  alert-dismissible fade show' role='alert'>Record Updated.</div>";
            redirectHome($theMsg,'settings.php',2);
        }else{
            $theMsg = "<div class='alert alert-secondary alert-dismissible fade show' role='alert'>Record not Updated.</div>";
            redirectHome($theMsg,'settings.php',2);
        }
    }
}else{
    $theMsg = "<div class='alert alert-danger'>You are not allowed to brows this page directly.</div>";
    redirectHome($theMsg,null,5);
}
?> </div><?php


    }elseif($do == 'Deletecolor') {
        ?> <div class="container">  
        <h3 class="">Delete Color</h3>
<?php
$itemsdetailsid = isset($_GET['itemsdetailsid']) && is_numeric($_GET['itemsdetailsid']) ? intval($_GET['itemsdetailsid']) : 0;
$check = checkItem('itemsdetails_ID', 'itemsdetails',$itemsdetailsid );
if($check == 1 ){
    $stmt = $con->prepare("DELETE FROM itemsdetails WHERE itemsdetails_ID = :zitemsdetails");
    $stmt->bindParam(":zitemsdetails", $itemsdetailsid);
    $stmt->execute();
    //update UPDATE `items` SET `color_ID` = 1 WHERE `items`.`color_ID` is null;
    $stmt = $con->prepare("UPDATE items 
    SET 
    color_ID = ?
    WHERE color_ID is null");
    $stmt->execute(array(1));


    $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Record Deleted.</div>";
    redirectHome($theMsg, 'settings.php?do=Manage', 2);
}else {
    // redirectHome($theMsg, $url = null, $seconds = 20)
    $theMsg = "<div class='alert alert-danger  alert-dismissible fade show' role='alert'>Invalid ID.</div>";
    redirectHome($theMsg, null, 2);
?> </div><?php
}


    }
    
    
    include $tpl . 'footer.php';
    
}else {
        header('location: index.php');
        exit();
}


ob_end_flush();