<?php

session_start();
$noNavbar = '';
$pageTitle = 'Login';
//print_r($_SESSION);
if(isset($_SESSION['Username'])){
    header('Location: dashboard.php');//redirect to dashboard
}

include 'init.php';


if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $username = $_POST['user'];
    $password = $_POST['password'];
    $hashedPass = sha1($password);
    
   

    //check if user exit in users table

    $stmt = $con->prepare("SELECT Username, UserID, Password, GroupID FROM users WHERE Username = ? AND Password = ? LIMIT 1");
    $stmt -> execute(array($username, $hashedPass));
    $row = $stmt->fetch();
    $count = $stmt->rowCount();

    //if count > 0, user exist

    if($count > 0){

        $_SESSION['Username'] = $username;//session name
        $_SESSION['ID'] = $row['UserID'];//session id
        $_SESSION['GroupID'] = $row['GroupID'];//session groupid
        header('Location: dashboard.php');//redirect to dashboard
        exit();
        
    }
}
?>
<main class="form-signin">
    <form class="login" action="<?php $_SERVER['PHP_SELF']?>" method="POST">
        <h4 class="h3 mb-3 fw-normal text-center">Sign In To Website Control Pannel</h4>

        <div class="form-floating">
        <input type="text" name="user" class="form-control" id="floatingInput" placeholder="Username" autocomplete="off">
        <label for="floatingInput">Username</label>
        </div>
        <div class="form-floating">
        <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password" autocomplete="off">
        <label for="floatingPassword">Password</label>
        </div>

        <!-- <div class="checkbox mb-3">
        <label>
            <input type="checkbox" value="remember-me"> Remember me
        </label>
        </div> -->
        <button class="w-100 btn btn-lg btn-primary" type="submit">Sign in</button>
      
    </form>
</main>

<?php
include $tpl.'footer.php';
?> 
 