<?php
ob_start();
$pageTitle = 'Dashboard';

session_start();

include 'init.php';

//print_r($_SESSION);
if(isset($_SESSION['Username'])){
// dashboard start


$latestUsers = 5;
$theLatestUsers = getLatest('*', 'users','WHERE GroupID != 1', 'UserID',$latestUsers);

$latestItems = 5;
//
$theLatestItems = getLatest('*', 'items',null , 'Item_ID',$latestItems);



//
?>
<div class="home-stats">
<div class="container text-center">
    <h3 class="">Dashboard</h3>
    <div class="row">
        <div class="col-md-3">
            <div class="stat st-members">
                <i class="fa fa-users"></i>
                <div class="info">
                    Total Users
                    <span><a href="members.php"><?php echo countItems('UserID', 'users','WHERE GroupID != 1')?></a></span>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat st-pending">
            <i class="fa fa-user-plus"></i>
                <div class="info">
                Pending Users
                <span><a href="members.php?members.php&page=pending"><?php echo countItems('UserID', 'users','WHERE GroupID != 1 AND RegStatus = 0')?></a></span>
            </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat st-items">
            <i class="fa fa-tag"></i>
                <div class="info">
            Total Items
               <span><a href="items.php"><?php echo countItems('Item_ID', 'items')?></a></span>
            </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat st-comments">
            <i class="fa fa-comment"></i>
                <div class="info">
                Total Comments
                <span><a href="comments.php"><?php echo countItems('c_id', 'comments')?></a></span>

            </div>
            </div>
        </div>

    </div>
</div>   
</div> 
<div class="home-stats">
<div class="container">
        <div class="col-md-12">
        <div class="accordion" id="accordionExample1">
        <div class="accordion-item accordion accordion-color">
            <h4 class="accordion-header" id="headingOne1">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne1">
                <i class="fa fa-users"></i>&nbsp;Latest <?php echo $latestUsers?> Registered Users
              </button>
            </h4>
            <div id="collapseOne1" class="accordion-collapse collapse show" aria-labelledby="headingOne1" data-bs-parent="#accordionExample1">
              <div class="accordion-body">
                <table class="table table-striped table-hover ">                
                        <tbody>                               
                            <?php       if(!empty($theLatestUsers)){                  
                                foreach ($theLatestUsers as $user){
                                    echo '<tr>';
                                    
                                    echo '<th scope="row">'. $user['Username'].'</th>';
                                    // echo '<td scope="row">'. $user['Username'].'</td>';
                                    if($user['GroupID'] != 1){
                                    echo '<td ><a href="members.php?do=Edit&userid='.$user['UserID'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> 
                                        <a href="members.php?do=Delete&userid='.$user['UserID'].'" class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a> ';
                                    if($user['RegStatus'] == 0){
                                    echo ' <a href="members.php?do=Activate&userid='.$user['UserID'].'" class="btn btn-outline-info btn-sm"><i class="fa fa-check"></i> Activate</a>';
                                        }
                                    echo '</td>'; 
                                    }                      
                                    echo '</tr>';
                                    }
                                }else{
                                    echo '<tr>';
                                    echo '<th scope="row">No Records to Display.</th>';
                                    echo '</tr>';

                                }
                            ?>                                                                                       
                    </tbody>
                </table>
              </div>
            </div>
          </div>        
        </div>
        </div>
        



        <div class="col-md-12">
        <div class="accordion" id="accordionExample2">
          <div class="accordion-item accordion accordion-color">
            <h4 class="accordion-header" id="headingOne2">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne2" aria-expanded="true" aria-controls="collapseOne2">
                 <i class="fa fa-tag"></i>&nbsp;Latest <?php echo $latestItems?> Items
              </button>
            </h4>
            <div id="collapseOne2" class="accordion-collapse collapse show" aria-labelledby="headingOne2" data-bs-parent="#accordionExample2">
              <div class="accordion-body">
                <table class="table table-striped table-hover ">                
                        <tbody>                               
                            <?php       if(!empty($theLatestItems)){                  
                                foreach ($theLatestItems as $item){
                                    echo '<tr>';
                                    echo '<th scope="row">'. $item['Name'].'</th>';
                                    echo '<td ><a href="items.php?do=Edit&itemid='.$item['Item_ID'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> 
                                        <a href="items.php?do=Delete&itemid='.$item['Item_ID'].'" class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a> ';
                                    if($item['TrustStatus'] == 0){
                                    echo ' <a href="items.php?do=Approve&itemid='.$item['Item_ID'].'" class="btn btn-outline-info btn-sm"><i class="fa fa-check"></i> Approve</a>';
                                        }
                                    echo '</td>';                       
                                    echo '</tr>';
                                    }
                                }else{
                                    echo '<tr>';
                                    echo '<th scope="row">No Records to Display.</th>';
                                    echo '</tr>';

                                }

                            ?>                                                                                       
                    </tbody>
                </table>
              </div>
            </div>
          </div>        
        </div>
        </div>
    </div>  

</div>
<div class="container home-stats">
<div>
        <div class="bd-example">
        <div class="accordion" id="accordionExample">
          <div class="accordion-item">
            <h4 class="accordion-header" id="headingOne">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
              <i class="fa fa-comments"></i>&nbsp;Latest 5 Comments
              </button>
            </h4>
            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
              <div class="accordion-body">
                <table class="table table-striped table-hover ">                
                    <tbody>                               

                    <?php 
                    $stmt = $con->prepare("SELECT 
                    comments.*, items.Name 
                    AS item_name, users.Username 
                    FROM comments 
                    INNER JOIN items 
                    ON items. Item_ID = comments. item_id 
                    INNER JOIN users 
                    ON users.UserID = comments.user_id LIMIT 5");
                    $stmt->execute();
                    $comments = $stmt->fetchAll();
                    if(!empty($comments)){ 
                    foreach ($comments as $comment){
                        echo '<tr>';
                        echo '<th scope="row">'. $comment['comment'].'</th>';
                        echo '<td ><a href="comments.php?do=Edit&commentid='.$comment['c_id'].'" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i>Edit</a> 
                            <a href="comments.php?do=Delete&commentid='.$comment['c_id'].'" class="btn btn-outline-danger btn-sm confirm"><i class="fa fa-trash"></i> Delete</a> ';
                        if($comment['TrustStatus'] == 0){
                        echo ' <a href="comments.php?do=Approve&commentid='.$comment['c_id'].'" class="btn btn-outline-info btn-sm"><i class="fa fa-check"></i> Approve</a>';
                            }
                        echo '</td>';                       
                        echo '</tr>';
                    }
                    }else{
                        echo '<tr>';
                        echo '<th scope="row">No Records to Display.</th>';
                        echo '</tr>';

                    }

                    ?>
                                </tbody>
                    </table>


            </div>
            </div>
          </div>
        </div>
        </div>
      </div>

</div>

<!--  -->
<?php  
//dashboard end
}else{
    // echo 'You Are Not Authorized To Brows This Page';

    header('Location: index.php');

    exist();
}
?>
<?php
include $tpl.'footer.php';
ob_flush();
?> 